"""Leitura e divisão de arquivos de pergaminhos.

Formato de arquivo adotado:

    # comentário (ignorado no cabeçote)
    ALQ-10492                              <- 1ª linha: identificador do decreto
    Selado na Terceira Era em 15/03/2043   <- selo temporal (DD/MM/AAAA)
    [Mestre Alabaster]                     <- assinatura do mago emissor
    ---                                    <- separador entre cabeçote e corpo
    abbcabc                                <- corpo: comandos rúnicos (alfabeto {a,b,c})
    ===                                    <- separador entre pergaminhos do mesmo arquivo
"""

from __future__ import annotations

from pathlib import Path

SEPARADOR_CORPO = "---"
SEPARADOR_PERGAMINHO = "==="


class ErroLeituraPergaminho(Exception):
    """Falha ao ler um arquivo de pergaminhos (inexistente, sem permissão, codificação)."""


def ler_arquivo(caminho: str | Path) -> str:
    """Lê um arquivo de texto em UTF-8 (aceita BOM), com mensagens de erro claras."""
    caminho = Path(caminho)
    try:
        return caminho.read_text(encoding="utf-8-sig")
    except FileNotFoundError as exc:
        raise ErroLeituraPergaminho(f"arquivo não encontrado: {caminho}") from exc
    except IsADirectoryError as exc:
        raise ErroLeituraPergaminho(f"é um diretório, não um arquivo: {caminho}") from exc
    except PermissionError as exc:
        raise ErroLeituraPergaminho(f"sem permissão para ler: {caminho}") from exc
    except UnicodeDecodeError as exc:
        raise ErroLeituraPergaminho(f"{caminho} não está codificado em UTF-8") from exc
    except OSError as exc:
        raise ErroLeituraPergaminho(f"erro ao ler {caminho}: {exc}") from exc


def _so_comentarios(bloco: str) -> bool:
    """True se o bloco não tem nenhuma linha útil (só vazias ou comentários '#')."""
    return all((not ln.strip()) or ln.strip().startswith("#") for ln in bloco.splitlines())


def dividir_pergaminhos(conteudo: str) -> list[str]:
    """Divide o conteúdo de um arquivo em pergaminhos, usando linhas ``===``.

    Blocos formados apenas por comentários/linhas vazias (ex.: cabeçalho do arquivo)
    são descartados.
    """
    blocos: list[list[str]] = [[]]
    for linha in conteudo.splitlines():
        if linha.strip() == SEPARADOR_PERGAMINHO:
            blocos.append([])
        else:
            blocos[-1].append(linha)
    textos = ["\n".join(b) for b in blocos]
    return [t for t in textos if not _so_comentarios(t)]


def separar_cabecalho_corpo(pergaminho: str) -> tuple[str, str, bool]:
    """Separa um pergaminho em ``(cabeçote, corpo, achou_separador)``.

    O separador é a primeira linha que, sem espaços nas pontas, é exatamente ``---``.
    Sem separador, todo o texto é tratado como cabeçote e o corpo fica vazio.
    """
    linhas = pergaminho.splitlines()
    for i, linha in enumerate(linhas):
        if linha.strip() == SEPARADOR_CORPO:
            return "\n".join(linhas[:i]), "\n".join(linhas[i + 1:]), True
    return pergaminho, "", False
