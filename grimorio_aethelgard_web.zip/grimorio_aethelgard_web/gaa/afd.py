"""Módulo 2 — Autômato Finito Determinístico (AFD) explícito.

Implementa um AFD genérico M = (Q, Σ, δ, q0, F) cuja função de transição δ é uma
*tabela* (dicionário ``(estado, símbolo) -> estado``). A leitura é feita caractere a
caractere, sem nenhuma biblioteca de expressões regulares.

Linguagem reconhecida pelo autômato dos comandos rúnicos (Σ = {a, b, c}):

    L = { w ∈ Σ*  |  #a(w) é par  e  w termina com "bc" }

Significado dos estados (invariante provado no relatório técnico). Após ler o prefixo u:

    q3  se #a(u) é ímpar;
    senão (#a(u) par):
        q2  se u termina com "bc"   (estado de aceitação)
        q1  se u termina com "b"
        q0  caso contrário (inclui a palavra vazia — estado inicial)

Este é o AFD *mínimo* de L (4 estados); ``numero_de_estados_minimo`` confirma isso
por refinamento de partições (algoritmo de Moore).
"""

from __future__ import annotations

from dataclasses import dataclass, field

Estado = str
Simbolo = str


class SimboloForaDoAlfabeto(ValueError):
    """A entrada contém um símbolo que não pertence ao alfabeto do autômato."""

    def __init__(self, simbolo: str, posicao: int) -> None:
        super().__init__(f"símbolo {simbolo!r} na posição {posicao} não pertence ao alfabeto")
        self.simbolo = simbolo
        self.posicao = posicao


class AutomatoInvalido(ValueError):
    """A definição formal do autômato é inconsistente (δ parcial, estados desconhecidos...)."""


@dataclass(frozen=True)
class Passo:
    """Uma transição realizada durante a simulação."""

    indice: int
    simbolo: Simbolo
    origem: Estado
    destino: Estado


@dataclass
class ResultadoAFD:
    aceita: bool
    estado_final: Estado
    passos: list[Passo] = field(default_factory=list)


class AFD:
    """Autômato Finito Determinístico completo, definido pela tupla (Q, Σ, δ, q0, F)."""

    def __init__(
        self,
        estados: tuple[Estado, ...],
        alfabeto: tuple[Simbolo, ...],
        delta: dict[tuple[Estado, Simbolo], Estado],
        inicial: Estado,
        finais: frozenset[Estado] | set[Estado],
        nome: str = "AFD",
    ) -> None:
        self.estados = tuple(estados)
        self.alfabeto = tuple(alfabeto)
        self.delta = dict(delta)
        self.inicial = inicial
        self.finais = frozenset(finais)
        self.nome = nome
        self._validar()

    # ------------------------------------------------------------------ #
    # Validação da definição formal
    # ------------------------------------------------------------------ #
    def _validar(self) -> None:
        if self.inicial not in self.estados:
            raise AutomatoInvalido(f"estado inicial {self.inicial!r} não pertence a Q")
        if not self.finais <= set(self.estados):
            raise AutomatoInvalido("F contém estados que não pertencem a Q")
        for q in self.estados:
            for s in self.alfabeto:
                if (q, s) not in self.delta:
                    raise AutomatoInvalido(f"δ({q}, {s}) indefinida: o AFD deve ser completo")
        for (q, s), destino in self.delta.items():
            if q not in self.estados or s not in self.alfabeto or destino not in self.estados:
                raise AutomatoInvalido(f"transição inválida δ({q}, {s}) = {destino}")

    # ------------------------------------------------------------------ #
    # Simulação
    # ------------------------------------------------------------------ #
    def processar(self, entrada: str) -> ResultadoAFD:
        """Lê ``entrada`` símbolo a símbolo a partir de q0 e informa se foi aceita.

        Levanta :class:`SimboloForaDoAlfabeto` ao encontrar símbolo fora de Σ.
        Complexidade: Θ(|entrada|) transições, cada uma com busca O(1) na tabela.
        """
        estado = self.inicial
        passos: list[Passo] = []
        for i, simbolo in enumerate(entrada):
            if simbolo not in self.alfabeto:
                raise SimboloForaDoAlfabeto(simbolo, i)
            destino = self.delta[(estado, simbolo)]
            passos.append(Passo(i, simbolo, estado, destino))
            estado = destino
        return ResultadoAFD(estado in self.finais, estado, passos)

    def aceita(self, entrada: str) -> bool:
        """Atalho: True se a palavra pertence à linguagem do autômato."""
        return self.processar(entrada).aceita

    # ------------------------------------------------------------------ #
    # Teoria: minimização (algoritmo de Moore por refinamento de partições)
    # ------------------------------------------------------------------ #
    def numero_de_estados_minimo(self) -> int:
        """Número de estados do AFD mínimo equivalente (só estados alcançáveis)."""
        alcancaveis = {self.inicial}
        fila = [self.inicial]
        while fila:
            q = fila.pop()
            for s in self.alfabeto:
                d = self.delta[(q, s)]
                if d not in alcancaveis:
                    alcancaveis.add(d)
                    fila.append(d)

        classe = {q: (1 if q in self.finais else 0) for q in alcancaveis}
        while True:
            assinatura = {
                q: (classe[q], tuple(classe[self.delta[(q, s)]] for s in self.alfabeto))
                for q in alcancaveis
            }
            ids = {sig: i for i, sig in enumerate(sorted(set(assinatura.values())))}
            nova = {q: ids[assinatura[q]] for q in alcancaveis}
            if len(set(nova.values())) == len(set(classe.values())):
                return len(set(nova.values()))
            classe = nova

    # ------------------------------------------------------------------ #
    # Apresentação
    # ------------------------------------------------------------------ #
    def tabela_transicao(self) -> str:
        """Tabela de transição em texto (``->`` inicial, ``*`` aceitação)."""
        largura = max(len(q) for q in self.estados) + 1
        cab = " " * 5 + "| " + " | ".join(f"{s:^{largura}}" for s in self.alfabeto)
        linhas = [cab, "-" * len(cab)]
        for q in self.estados:
            marca = ("->" if q == self.inicial else "  ") + ("*" if q in self.finais else " ")
            celulas = " | ".join(f"{self.delta[(q, s)]:^{largura}}" for s in self.alfabeto)
            linhas.append(f"{marca} {q:<{largura}}| {celulas}")
        return "\n".join(linhas)

    def descricao_formal(self) -> str:
        """Definição formal M = (Q, Σ, δ, q0, F) em texto."""
        return (
            f"M = (Q, Σ, δ, q0, F)\n"
            f"  Q  = {{{', '.join(self.estados)}}}\n"
            f"  Σ  = {{{', '.join(self.alfabeto)}}}\n"
            f"  q0 = {self.inicial}\n"
            f"  F  = {{{', '.join(sorted(self.finais))}}}\n"
            f"  δ  =\n{self.tabela_transicao()}"
        )

    def para_dot(self) -> str:
        """Diagrama do AFD na linguagem DOT (Graphviz), agrupando rótulos de arestas iguais."""
        linhas = [
            f'digraph "{self.nome}" {{',
            "  rankdir=LR;",
            '  node [shape=circle, fontname="Helvetica", fontsize=14];',
            '  edge [fontname="Helvetica", fontsize=13];',
            '  __inicio [shape=point, label=""];',
        ]
        for q in self.estados:
            forma = "doublecircle" if q in self.finais else "circle"
            linhas.append(f"  {q} [shape={forma}];")
        linhas.append(f"  __inicio -> {self.inicial};")
        agrupado: dict[tuple[Estado, Estado], list[Simbolo]] = {}
        for q in self.estados:
            for s in self.alfabeto:
                agrupado.setdefault((q, self.delta[(q, s)]), []).append(s)
        for (origem, destino), simbolos in agrupado.items():
            linhas.append(f'  {origem} -> {destino} [label="{",".join(simbolos)}"];')
        linhas.append("}")
        return "\n".join(linhas)


# --------------------------------------------------------------------------- #
# O autômato dos comandos rúnicos
# --------------------------------------------------------------------------- #
SIGNIFICADO_ESTADOS = {
    "q0": "par de 'a' e a entrada não termina em 'b' nem em 'bc' (inicial)",
    "q1": "par de 'a' e a entrada termina em 'b'",
    "q2": "par de 'a' e a entrada termina em 'bc' (ACEITAÇÃO)",
    "q3": "quantidade ímpar de 'a' (estado 'armadilha de paridade')",
}


def criar_afd_runico() -> AFD:
    """Constrói o AFD de L = {w ∈ {a,b,c}* : #a(w) par e w termina com 'bc'}."""
    delta = {
        ("q0", "a"): "q3", ("q0", "b"): "q1", ("q0", "c"): "q0",
        ("q1", "a"): "q3", ("q1", "b"): "q1", ("q1", "c"): "q2",
        ("q2", "a"): "q3", ("q2", "b"): "q1", ("q2", "c"): "q0",
        ("q3", "a"): "q0", ("q3", "b"): "q3", ("q3", "c"): "q3",
    }
    return AFD(
        estados=("q0", "q1", "q2", "q3"),
        alfabeto=("a", "b", "c"),
        delta=delta,
        inicial="q0",
        finais={"q2"},
        nome="AFD_comandos_runicos",
    )
