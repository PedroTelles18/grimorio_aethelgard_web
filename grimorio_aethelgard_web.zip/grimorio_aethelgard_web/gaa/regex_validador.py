"""Módulo 1 — Reconhecimento por Expressões Regulares.

Valida o *cabeçote de segurança* de um pergaminho:

1. Identificador de Decreto — 3 letras maiúsculas, hífen, 4 a 6 dígitos;
2. Selo Temporal Mágico     — data DD/MM/AAAA com ano entre 2000 e 2099;
3. Assinatura do Mago       — letras e espaços entre colchetes, 5 a 40 caracteres.

Decisões de projeto (justificadas no relatório técnico):

* ``[0-9]`` e ``[A-Z]`` em vez de ``\\d`` e ``\\w``: em Python 3, ``\\d`` casa dígitos
  de *qualquer* alfabeto Unicode (ex.: "٣"), o que abriria uma brecha para falsificadores.
* Os padrões de ID e assinatura são aplicados com ``fullmatch`` (ancoragem total).
* A data usa *lookarounds* (``(?<![0-9/])`` e ``(?![0-9/])``) para não aceitar
  "15/03/20431" nem "115/03/2043" como se contivessem uma data correta.
* Uma regex não verifica o calendário (31/02, 29/02 em ano não bissexto); essa
  checagem semântica é feita depois do casamento do padrão e gera um código próprio.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date

from .modelos import E_ASSINATURA, E_DATA, E_DATA_INEXISTENTE, E_ESTRUTURA, E_ID, Falha

# --------------------------------------------------------------------------- #
# Expressões regulares
# --------------------------------------------------------------------------- #

# Identificador: exatamente 3 maiúsculas (A-Z), hífen, 4 a 6 dígitos.
PADRAO_ID = re.compile(r"(?P<guilda>[A-Z]{3})-(?P<numero>[0-9]{4,6})")

# Selo temporal: DD (01-31) / MM (01-12) / AAAA (2000-2099), isolado de outros dígitos e barras.
PADRAO_DATA = re.compile(
    r"(?<![0-9/])"
    r"(?P<dia>0[1-9]|[12][0-9]|3[01])/"
    r"(?P<mes>0[1-9]|1[0-2])/"
    r"(?P<ano>20[0-9]{2})"
    r"(?![0-9/])"
)

# Padrão "frouxo": apenas para *diagnosticar* por que uma data não casou com o padrão estrito.
_PADRAO_DATA_FROUXO = re.compile(r"[0-9]+/[0-9]+/[0-9]+")

# Qualquer grupo entre colchetes (usado para localizar a assinatura e diagnosticá-la).
_PADRAO_COLCHETES = re.compile(r"\[[^\]\n]*\]")

# Assinatura: '[' + 5 a 40 (letras Unicode ou espaço) + ']'.
#   [^\W\d_] = "caractere de palavra que não é dígito nem sublinhado" = letra (aceita acentos).
#   O lookahead exige ao menos uma letra, para recusar "[     ]".
PADRAO_ASSINATURA = re.compile(r"\[(?=[^\]]*[^\W\d_])(?P<nome>(?:[^\W\d_]| ){5,40})\]")

# Prefixo de guilda legível (para contabilizar fraudes mesmo quando o número do ID está errado).
_PREFIXO_GUILDA = re.compile(r"([A-Z]{3})(?=-)")

TAMANHO_MAXIMO_CHAVE = 80  # limite do texto bruto usado como chave quando o ID é inválido


@dataclass
class CabecalhoValidado:
    """Resultado da validação do cabeçote."""

    identificador: str | None          # 1ª linha do cabeçote (bruta, truncada); None se vazio
    guilda: str | None                 # guilda identificada (válida ou apenas pelo prefixo)
    data: str | None                   # data DD/MM/AAAA encontrada e existente
    assinatura: str | None             # nome do mago (sem colchetes) se válido
    falhas: list[Falha] = field(default_factory=list)

    @property
    def valido(self) -> bool:
        return not self.falhas


def extrair_guilda(texto_id: str) -> str | None:
    """Extrai as 3 letras da guilda se o texto começa com ``GGG-`` (mesmo com ID inválido)."""
    m = _PREFIXO_GUILDA.match(texto_id)
    return m.group(1) if m else None


def data_existe(dia: int, mes: int, ano: int) -> bool:
    """Verifica no calendário gregoriano se a data existe (trata anos bissextos)."""
    try:
        date(ano, mes, dia)
    except ValueError:
        return False
    return True


# --------------------------------------------------------------------------- #
# Validações por campo
# --------------------------------------------------------------------------- #
def _validar_id(texto_id: str) -> tuple[str | None, Falha | None]:
    m = PADRAO_ID.fullmatch(texto_id)
    if m:
        return m.group("guilda"), None
    return extrair_guilda(texto_id), Falha(
        E_ID,
        f"identificador {texto_id!r} fora do padrão: exige 3 letras maiúsculas, "
        "hífen e 4 a 6 dígitos (ex.: ALQ-10492)",
    )


def _validar_data(resto: str) -> tuple[str | None, Falha | None]:
    m = PADRAO_DATA.search(resto)
    if m:
        dia, mes, ano = int(m["dia"]), int(m["mes"]), int(m["ano"])
        texto = m.group(0)
        if not data_existe(dia, mes, ano):
            return None, Falha(E_DATA_INEXISTENTE, f"a data {texto} não existe no calendário")
        return texto, None

    # Não casou: descobrir o motivo para dar uma mensagem útil aos guardas.
    frouxa = _PADRAO_DATA_FROUXO.search(resto)
    if frouxa is None:
        return None, Falha(E_DATA, "selo temporal ausente: nenhuma data DD/MM/AAAA encontrada")
    texto = frouxa.group(0)
    ano = texto.split("/")[2]
    if len(ano) == 4 and not ano.startswith("20"):
        return None, Falha(E_DATA, f"ano {ano} fora da Terceira Era (2000 a 2099) em {texto}")
    return None, Falha(E_DATA, f"{texto!r} fora do formato DD/MM/AAAA")


def _validar_assinatura(resto: str) -> tuple[str | None, Falha | None]:
    grupos = _PADRAO_COLCHETES.findall(resto)
    if not grupos:
        return None, Falha(E_ASSINATURA, "assinatura do Mago Emissor ausente (esperado [Nome do Mago])")

    grupo = grupos[0]  # apenas a primeira assinatura é considerada
    m = PADRAO_ASSINATURA.fullmatch(grupo)
    if m:
        return m.group("nome"), None

    interior = grupo[1:-1]
    motivos = []
    if re.search(r"\d", interior):
        motivos.append("contém números")
    if re.search(r"[^\w ]|_", interior):
        motivos.append("contém caracteres que não são letras nem espaços")
    if not 5 <= len(interior) <= 40:
        motivos.append(f"tem {len(interior)} caracteres (exigido: 5 a 40)")
    if not re.search(r"[^\W\d_]", interior):
        motivos.append("não contém nenhuma letra")
    if not motivos:  # salvaguarda; não deve ocorrer
        motivos.append("fora do padrão")
    return None, Falha(E_ASSINATURA, f"assinatura {grupo!r} inválida: " + "; ".join(motivos))


# --------------------------------------------------------------------------- #
# API pública do módulo
# --------------------------------------------------------------------------- #
def validar_cabecalho(cabecalho: str) -> CabecalhoValidado:
    """Valida o cabeçote completo e devolve *todas* as falhas encontradas.

    Formato esperado: a primeira linha não vazia é o identificador; a data e a
    assinatura devem constar nas linhas seguintes. Linhas iniciadas por ``#`` são
    comentários e são ignoradas.
    """
    texto = unicodedata.normalize("NFC", cabecalho)  # "á" decomposto -> "á" composto
    linhas = [ln.strip() for ln in texto.splitlines()]
    linhas = [ln for ln in linhas if ln and not ln.startswith("#")]

    if not linhas:
        return CabecalhoValidado(
            None, None, None, None,
            [Falha(E_ESTRUTURA, "cabeçote vazio: o pergaminho não possui identificador")],
        )

    identificador = linhas[0][:TAMANHO_MAXIMO_CHAVE]
    resto = "\n".join(linhas[1:])

    guilda, falha_id = _validar_id(linhas[0])
    data, falha_data = _validar_data(resto)
    assinatura, falha_assin = _validar_assinatura(resto)

    falhas = [f for f in (falha_id, falha_data, falha_assin) if f is not None]
    return CabecalhoValidado(identificador, guilda, data, assinatura, falhas)
