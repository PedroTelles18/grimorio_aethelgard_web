"""Interface de linha de comando (CLI) do Grimório Automático de Auditoria.

Comandos:
    auditar ARQ [ARQ ...] [--buscar ID ...] [--relatorio SAIDA.txt|json] [--resumido]
    afd PALAVRA [--passos] [--tabela]
    interativo [ARQ ...]
    demo
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .afd import SIGNIFICADO_ESTADOS, SimboloForaDoAlfabeto, criar_afd_runico
from .auditor import Auditor
from .modelos import Registro
from .pergaminho import ErroLeituraPergaminho

BANNER = (
    "================================================================\n"
    " GRIMORIO AUTOMATICO DE AUDITORIA (GAA) v{versao}\n"
    " Ordem dos Arquivistas e Mestres do Saber - Reino de Aethelgard\n"
    "================================================================"
)

AJUDA_INTERATIVO = """Comandos do Grimório:
  carregar <arquivo> [...]   audita os pergaminhos de um ou mais arquivos
  buscar <ID>                consulta o status de um pergaminho pelo identificador
  ranking                    ranking de guildas por tentativas de fraude
  relatorio <arquivo>        grava o relatório (.txt ou .json)
  afd <palavra>              executa o autômato dos comandos rúnicos passo a passo
  estatisticas               métricas da tabela hash
  ajuda                      mostra esta ajuda
  sair                       encerra"""


# --------------------------------------------------------------------------- #
# Formatação
# --------------------------------------------------------------------------- #
def formatar_registro(r: Registro, detalhado: bool = True) -> str:
    if r.autentico:
        info = f"[AUTENTICO]  {r.identificador}  guilda={r.guilda}  data={r.data}  mago={r.assinatura}"
        return info
    linha = f"[REJEITADO]  {r.identificador}  guilda={r.guilda or 'desconhecida'}"
    if detalhado:
        for falha in r.falhas:
            linha += f"\n    - {falha}"
    else:
        linha += "  motivos=" + ",".join(f.codigo for f in r.falhas)
    return linha


def imprimir_ranking(auditor: Auditor) -> None:
    ranking = auditor.ranking()
    print("Ranking de guildas por tentativas de fraude:")
    if not ranking:
        print("  (nenhuma tentativa de fraude registrada)")
    for pos, (guilda, n) in enumerate(ranking, start=1):
        print(f"  {pos:>2}. {guilda}  {n} tentativa(s)")
    if auditor.fraudes_sem_guilda:
        print(f"  (+ {auditor.fraudes_sem_guilda} tentativa(s) sem guilda identificável)")


def imprimir_resumo(auditor: Auditor) -> None:
    r = auditor.resumo()
    print(
        f"Resumo: {r['submissoes']} auditado(s) | {r['autenticas']} autêntico(s) | "
        f"{r['rejeitadas']} rejeitado(s) | {r['pergaminhos_no_inventario']} no inventário"
    )


def executar_afd(palavra: str, passos: bool = True, tabela: bool = False) -> int:
    afd = criar_afd_runico()
    if tabela:
        print(afd.descricao_formal())
        print()
        for q, significado in SIGNIFICADO_ESTADOS.items():
            print(f"  {q}: {significado}")
        print()
    try:
        resultado = afd.processar(palavra)
    except SimboloForaDoAlfabeto as exc:
        print(f"REJEITADA: {exc}")
        return 1
    print(f"Palavra: {palavra!r}")
    print(f"Estado inicial: {afd.inicial}")
    if passos:
        for p in resultado.passos:
            print(f"  [{p.indice}] δ({p.origem}, {p.simbolo}) = {p.destino}")
    veredito = "ACEITA" if resultado.aceita else "REJEITADA"
    print(f"Estado final: {resultado.estado_final}  ->  {veredito}")
    return 0 if resultado.aceita else 1


# --------------------------------------------------------------------------- #
# Comandos
# --------------------------------------------------------------------------- #
def _carregar(auditor: Auditor, arquivos: list[str], detalhado: bool) -> bool:
    """Audita os arquivos; devolve False se algum não pôde ser lido."""
    ok = True
    for arquivo in arquivos:
        try:
            registros = auditor.auditar_arquivo(arquivo)
        except ErroLeituraPergaminho as exc:
            print(f"ERRO: {exc}", file=sys.stderr)
            ok = False
            continue
        print(f"--- {arquivo}: {len(registros)} pergaminho(s) ---")
        for r in registros:
            print(formatar_registro(r, detalhado))
    return ok


def _gravar_relatorio(auditor: Auditor, destino: str) -> bool:
    try:
        caminho = auditor.gerar_relatorio(destino)
    except (ValueError, OSError) as exc:
        print(f"ERRO: não foi possível gerar o relatório: {exc}", file=sys.stderr)
        return False
    print(f"Relatório gravado em: {caminho}")
    return True


def cmd_auditar(args: argparse.Namespace) -> int:
    auditor = Auditor()
    ok = _carregar(auditor, args.arquivos, detalhado=not args.resumido)
    print()
    imprimir_resumo(auditor)
    print()
    imprimir_ranking(auditor)
    for ident in args.buscar or []:
        print()
        registro = auditor.buscar(ident)
        print(f"Consulta '{ident}':")
        print("  " + (formatar_registro(registro).replace("\n", "\n  ") if registro else "pergaminho não encontrado no inventário"))
    if args.relatorio:
        print()
        ok = _gravar_relatorio(auditor, args.relatorio) and ok
    return 0 if ok else 1


def cmd_afd(args: argparse.Namespace) -> int:
    return executar_afd(args.palavra, passos=args.passos, tabela=args.tabela)


def cmd_interativo(args: argparse.Namespace) -> int:
    auditor = Auditor()
    print(BANNER.format(versao=__version__))
    print("Digite 'ajuda' para ver os comandos.\n")
    if args.arquivos:
        _carregar(auditor, args.arquivos, detalhado=False)
        imprimir_resumo(auditor)
    while True:
        try:
            linha = input("grimorio> ").strip()
        except EOFError:
            print()
            break
        if not linha:
            continue
        comando, *resto = linha.split(maxsplit=1)
        argumento = resto[0] if resto else ""
        comando = comando.lower()
        if comando in ("sair", "exit", "quit"):
            break
        elif comando == "ajuda":
            print(AJUDA_INTERATIVO)
        elif comando == "carregar":
            if not argumento:
                print("uso: carregar <arquivo> [...]")
            else:
                _carregar(auditor, argumento.split(), detalhado=False)
                imprimir_resumo(auditor)
        elif comando == "buscar":
            if not argumento:
                print("uso: buscar <ID>")
            else:
                r = auditor.buscar(argumento)
                print(formatar_registro(r) if r else "pergaminho não encontrado no inventário")
        elif comando == "ranking":
            imprimir_ranking(auditor)
        elif comando == "relatorio":
            if not argumento:
                print("uso: relatorio <arquivo.txt|arquivo.json>")
            else:
                _gravar_relatorio(auditor, argumento)
        elif comando == "afd":
            executar_afd(argumento, passos=True)
        elif comando == "estatisticas":
            for k, v in auditor.inventario.estatisticas().items():
                print(f"  {k}: {v}")
        else:
            print(f"comando desconhecido: {comando!r} (digite 'ajuda')")
    print("Que a luz de Aethelgard guie os guardas. Até breve!")
    return 0


def cmd_demo(_: argparse.Namespace) -> int:
    pasta = Path(__file__).resolve().parent.parent / "exemplos"
    arquivos = [str(pasta / "decretos_validos.txt"), str(pasta / "decretos_invalidos.txt")]
    print(BANNER.format(versao=__version__))
    auditor = Auditor()
    ok = _carregar(auditor, arquivos, detalhado=False)
    print()
    imprimir_resumo(auditor)
    print()
    imprimir_ranking(auditor)
    print("\nConsulta de exemplo: buscar ALQ-10492")
    r = auditor.buscar("ALQ-10492")
    print("  " + (formatar_registro(r) if r else "não encontrado"))
    return 0 if ok else 1


# --------------------------------------------------------------------------- #
# Ponto de entrada
# --------------------------------------------------------------------------- #
def construir_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="Grimório Automático de Auditoria — detector de pergaminhos falsificados de Aethelgard.",
    )
    sub = parser.add_subparsers(dest="comando", required=True)

    p = sub.add_parser("auditar", help="audita arquivos de pergaminhos")
    p.add_argument("arquivos", nargs="+", help="arquivos de pergaminhos (.txt)")
    p.add_argument("--buscar", "-b", action="append", metavar="ID", help="consulta um ID após a auditoria (repetível)")
    p.add_argument("--relatorio", "-r", metavar="SAIDA", help="grava o relatório de fraudes (.txt ou .json)")
    p.add_argument("--resumido", action="store_true", help="uma linha por pergaminho, sem detalhar motivos")
    p.set_defaults(func=cmd_auditar)

    p = sub.add_parser("afd", help="executa o autômato dos comandos rúnicos sobre uma palavra")
    p.add_argument("palavra", help="sequência sobre {a,b,c} (use '' para a palavra vazia)")
    p.add_argument("--passos", action="store_true", help="mostra cada transição")
    p.add_argument("--tabela", action="store_true", help="mostra a definição formal e a tabela de transição")
    p.set_defaults(func=cmd_afd)

    p = sub.add_parser("interativo", help="modo interativo para consulta dos guardas")
    p.add_argument("arquivos", nargs="*", help="arquivos a carregar na abertura")
    p.set_defaults(func=cmd_interativo)

    p = sub.add_parser("demo", help="audita os exemplos incluídos no projeto")
    p.set_defaults(func=cmd_demo)
    return parser


def main(argv: list[str] | None = None) -> int:
    # Evita UnicodeEncodeError em consoles que não usam UTF-8 (ex.: Windows).
    for fluxo in (sys.stdout, sys.stderr):
        if hasattr(fluxo, "reconfigure"):
            fluxo.reconfigure(encoding="utf-8", errors="replace")
    args = construir_parser().parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\nInterrompido.", file=sys.stderr)
        return 130
