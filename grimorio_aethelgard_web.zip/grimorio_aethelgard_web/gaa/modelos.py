"""Tipos de dados e constantes compartilhados entre os módulos do GAA."""

from __future__ import annotations

from dataclasses import dataclass, field

# --------------------------------------------------------------------------- #
# Estados possíveis de um pergaminho auditado
# --------------------------------------------------------------------------- #
STATUS_AUTENTICO = "AUTENTICO"
STATUS_REJEITADO = "REJEITADO"

# --------------------------------------------------------------------------- #
# Códigos de fraude (motivos de rejeição)
# --------------------------------------------------------------------------- #
E_ESTRUTURA = "E_ESTRUTURA"            # cabeçote vazio ou separador '---' ausente
E_ID = "E_ID"                          # identificador de decreto fora do padrão
E_DATA = "E_DATA"                      # selo temporal ausente / fora do padrão / fora da Terceira Era
E_DATA_INEXISTENTE = "E_DATA_INEXISTENTE"  # formato correto, mas dia inexistente (ex.: 31/02)
E_ASSINATURA = "E_ASSINATURA"          # assinatura do mago ausente ou inválida
E_CORPO_ALFABETO = "E_CORPO_ALFABETO"  # corpo contém símbolo fora de {a, b, c}
E_CORPO_AFD = "E_CORPO_AFD"            # corpo rejeitado pelo autômato (paridade de 'a' / sufixo 'bc')

DESCRICAO_CODIGOS = {
    E_ESTRUTURA: "Estrutura do pergaminho inválida (cabeçote vazio ou separador '---' ausente)",
    E_ID: "Identificador de decreto fora do padrão GGG-NNNN[NN]",
    E_DATA: "Selo temporal ausente, fora do formato DD/MM/AAAA ou fora da Terceira Era",
    E_DATA_INEXISTENTE: "Selo temporal com dia inexistente no calendário",
    E_ASSINATURA: "Assinatura do Mago Emissor ausente ou inválida",
    E_CORPO_ALFABETO: "Corpo com símbolo fora do alfabeto {a, b, c}",
    E_CORPO_AFD: "Comandos rúnicos rejeitados pelo autômato",
}


@dataclass(frozen=True)
class Falha:
    """Um motivo de fraude detectado em um pergaminho."""

    codigo: str
    mensagem: str

    def __str__(self) -> str:
        return f"{self.codigo}: {self.mensagem}"


@dataclass
class Registro:
    """Resultado da auditoria de um pergaminho (valor guardado na tabela hash)."""

    identificador: str                     # chave de busca (ID do decreto ou texto bruto da 1ª linha)
    guilda: str | None                     # 3 letras da guilda, quando identificável
    status: str                            # STATUS_AUTENTICO ou STATUS_REJEITADO
    falhas: list[Falha] = field(default_factory=list)
    data: str | None = None                # selo temporal encontrado (se válido)
    assinatura: str | None = None          # nome do mago emissor (se válido)
    auditorias: int = 1                    # quantas vezes este ID foi auditado

    @property
    def autentico(self) -> bool:
        return self.status == STATUS_AUTENTICO

    def para_dict(self) -> dict:
        return {
            "identificador": self.identificador,
            "guilda": self.guilda,
            "status": self.status,
            "data": self.data,
            "assinatura": self.assinatura,
            "auditorias": self.auditorias,
            "falhas": [{"codigo": f.codigo, "mensagem": f.mensagem} for f in self.falhas],
        }
