"""Grimório Automático de Auditoria (GAA) — Reino de Aethelgard.

Pacote organizado em módulos independentes:

* ``regex_validador`` — Módulo 1: reconhecimento do cabeçote por Expressões Regulares;
* ``afd``             — Módulo 2: Autômato Finito Determinístico explícito (tabela de transição);
* ``estruturas``      — Módulo 3: Tabela Hash com encadeamento separado (implementada do zero);
* ``auditor``         — orquestra os três módulos e gera os relatórios;
* ``cli``             — interface de linha de comando (comandos e modo interativo).
"""

__version__ = "1.0.0"
