"""Auditor — orquestra Regex (Módulo 1), AFD (Módulo 2) e Tabela Hash (Módulo 3).

Fluxo de auditoria de cada pergaminho:

    texto ──► separar cabeçote / corpo
          ──► Módulo 1: Regex valida ID, data e assinatura do cabeçote
          ──► (só se o cabeçote for válido) Módulo 2: AFD processa o corpo símbolo a símbolo
          ──► Módulo 3: Registro (autêntico ou rejeitado + motivos) vai para a Tabela Hash
          ──► se rejeitado, a guilda ganha +1 tentativa de fraude (ranking)
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from .afd import AFD, SimboloForaDoAlfabeto, criar_afd_runico
from .estruturas import TabelaHash
from .modelos import (
    DESCRICAO_CODIGOS,
    E_CORPO_AFD,
    E_CORPO_ALFABETO,
    E_ESTRUTURA,
    STATUS_AUTENTICO,
    STATUS_REJEITADO,
    Falha,
    Registro,
)
from .pergaminho import SEPARADOR_CORPO, dividir_pergaminhos, ler_arquivo, separar_cabecalho_corpo
from .regex_validador import validar_cabecalho


def _incrementar(tabela: TabelaHash, chave: str) -> None:
    tabela.inserir(chave, tabela.buscar(chave, 0) + 1)


class Auditor:
    """Grimório Automático de Auditoria: audita pergaminhos e guarda o inventário."""

    def __init__(self, capacidade_inicial: int = 16) -> None:
        self.inventario = TabelaHash(capacidade_inicial)   # ID -> Registro
        self._fraudes_por_guilda = TabelaHash()            # guilda -> nº de tentativas
        self._motivos = TabelaHash()                       # código de falha -> ocorrências
        self._fraudes_sem_guilda = 0
        self._submissoes = 0
        self._autenticas = 0
        self._rejeitadas = 0
        self._seq_sem_id = 0
        self.afd: AFD = criar_afd_runico()

    # ------------------------------------------------------------------ #
    # Auditoria
    # ------------------------------------------------------------------ #
    def auditar_pergaminho(self, texto: str) -> Registro:
        """Audita um pergaminho (texto completo) e o registra no inventário."""
        cabecalho, corpo, achou_separador = separar_cabecalho_corpo(texto)

        # Módulo 1 — Expressões Regulares
        res = validar_cabecalho(cabecalho)
        falhas: list[Falha] = list(res.falhas)
        if not achou_separador:
            falhas.append(Falha(
                E_ESTRUTURA,
                f"separador '{SEPARADOR_CORPO}' ausente: corpo do decreto não encontrado",
            ))

        # Módulo 2 — AFD (somente após a pré-validação da Regex ter passado)
        if res.valido and achou_separador:
            falha_corpo = self._verificar_corpo(corpo.strip())
            if falha_corpo is not None:
                falhas.append(falha_corpo)

        # Chave de busca: ID (ou texto bruto da 1ª linha); sem cabeçote algum, gera uma chave sintética
        chave = res.identificador
        if chave is None:
            self._seq_sem_id += 1
            chave = f"<SEM-ID-{self._seq_sem_id}>"

        anterior = self.inventario.buscar(chave)
        registro = Registro(
            identificador=chave,
            guilda=res.guilda,
            status=STATUS_REJEITADO if falhas else STATUS_AUTENTICO,
            falhas=falhas,
            data=res.data,
            assinatura=res.assinatura,
            auditorias=(anterior.auditorias + 1) if anterior is not None else 1,
        )

        # Módulo 3 — Estrutura de dados e estatísticas
        self.inventario.inserir(chave, registro)
        self._submissoes += 1
        if registro.autentico:
            self._autenticas += 1
        else:
            self._rejeitadas += 1
            if registro.guilda is not None:
                _incrementar(self._fraudes_por_guilda, registro.guilda)
            else:
                self._fraudes_sem_guilda += 1
            for falha in registro.falhas:
                _incrementar(self._motivos, falha.codigo)
        return registro

    def _verificar_corpo(self, corpo: str) -> Falha | None:
        """Executa o AFD sobre o corpo. Devolve a falha, ou None se o corpo for aceito."""
        try:
            resultado = self.afd.processar(corpo)
        except SimboloForaDoAlfabeto as exc:
            return Falha(
                E_CORPO_ALFABETO,
                f"símbolo {exc.simbolo!r} na posição {exc.posicao} do corpo não pertence a {{a, b, c}}",
            )
        if resultado.aceita:
            return None
        # O motivo é lido do estado em que o autômato parou (ver significado dos estados em afd.py).
        if resultado.estado_final == "q3":
            motivo = "quantidade ímpar de símbolos 'a'"
        else:
            motivo = "quantidade par de 'a', mas a sequência não termina com 'bc'"
        return Falha(E_CORPO_AFD, f"comandos rúnicos rejeitados pelo AFD (parou em {resultado.estado_final}): {motivo}")

    def auditar_texto(self, conteudo: str) -> list[Registro]:
        """Audita todos os pergaminhos de um conteúdo (separados por linhas ``===``)."""
        return [self.auditar_pergaminho(p) for p in dividir_pergaminhos(conteudo)]

    def auditar_arquivo(self, caminho: str | Path) -> list[Registro]:
        """Lê um arquivo de pergaminhos e audita todos eles."""
        return self.auditar_texto(ler_arquivo(caminho))

    # ------------------------------------------------------------------ #
    # Consultas
    # ------------------------------------------------------------------ #
    def buscar(self, identificador: str) -> Registro | None:
        """Consulta imediata do status de um pergaminho pelo identificador."""
        return self.inventario.buscar(identificador.strip())

    def registros(self) -> list[Registro]:
        """Todos os registros do inventário, ordenados por identificador."""
        return sorted((r for _, r in self.inventario.itens()), key=lambda r: r.identificador)

    def ranking(self) -> list[tuple[str, int]]:
        """Guildas ordenadas por nº de tentativas de fraude (desc.; empate: ordem alfabética)."""
        itens = list(self._fraudes_por_guilda.itens())
        itens.sort(key=lambda par: (-par[1], par[0]))
        return itens

    @property
    def fraudes_sem_guilda(self) -> int:
        return self._fraudes_sem_guilda

    def resumo(self) -> dict:
        return {
            "submissoes": self._submissoes,
            "autenticas": self._autenticas,
            "rejeitadas": self._rejeitadas,
            "pergaminhos_no_inventario": len(self.inventario),
        }

    def motivos(self) -> list[tuple[str, int]]:
        """Ocorrências por código de falha (desc.)."""
        itens = list(self._motivos.itens())
        itens.sort(key=lambda par: (-par[1], par[0]))
        return itens

    # ------------------------------------------------------------------ #
    # Relatórios
    # ------------------------------------------------------------------ #
    def relatorio_texto(self) -> str:
        r = self.resumo()
        linhas = [
            "=" * 66,
            " GRIMORIO AUTOMATICO DE AUDITORIA - Reino de Aethelgard",
            " Relatorio de Tentativas de Fraude por Guilda",
            "=" * 66,
            f"Gerado em: {datetime.now().isoformat(timespec='seconds')}",
            "",
            f"Pergaminhos auditados (submissões) : {r['submissoes']}",
            f"  Autênticos                       : {r['autenticas']}",
            f"  Rejeitados (tentativas de fraude): {r['rejeitadas']}",
            f"Pergaminhos distintos no inventário: {r['pergaminhos_no_inventario']}",
            "",
            "RANKING DE GUILDAS (mais tentativas de fraude primeiro)",
            "-" * 66,
            f"{'Pos.':<6}{'Guilda':<10}{'Tentativas de fraude':>22}",
        ]
        ranking = self.ranking()
        if ranking:
            for pos, (guilda, n) in enumerate(ranking, start=1):
                linhas.append(f"{pos:<6}{guilda:<10}{n:>22}")
        else:
            linhas.append("(nenhuma tentativa de fraude registrada)")
        linhas += [
            "",
            f"Tentativas cuja guilda não pôde ser identificada: {self._fraudes_sem_guilda}",
            "",
            "MOTIVOS DE REJEIÇÃO (ocorrências)",
            "-" * 66,
        ]
        motivos = self.motivos()
        if motivos:
            for codigo, n in motivos:
                linhas.append(f"{codigo:<20}{n:>5}  {DESCRICAO_CODIGOS.get(codigo, '')}")
        else:
            linhas.append("(nenhum)")
        e = self.inventario.estatisticas()
        linhas += [
            "",
            "ESTRUTURA DE DADOS (tabela hash com encadeamento)",
            "-" * 66,
            f"chaves={e['chaves']}  baldes={e['baldes']}  fator de carga={e['fator_de_carga']}  "
            f"colisões={e['colisoes']}  maior cadeia={e['maior_cadeia']}",
            "",
        ]
        return "\n".join(linhas)

    def relatorio_dict(self) -> dict:
        return {
            "gerado_em": datetime.now().isoformat(timespec="seconds"),
            "resumo": self.resumo(),
            "ranking_guildas": [
                {"posicao": i, "guilda": g, "tentativas_de_fraude": n}
                for i, (g, n) in enumerate(self.ranking(), start=1)
            ],
            "tentativas_sem_guilda_identificada": self._fraudes_sem_guilda,
            "motivos_de_rejeicao": {c: n for c, n in self.motivos()},
            "estrutura_de_dados": self.inventario.estatisticas(),
            "pergaminhos_rejeitados": [r.para_dict() for r in self.registros() if not r.autentico],
        }

    def gerar_relatorio(self, caminho: str | Path) -> Path:
        """Grava o relatório em ``.txt`` ou ``.json`` (conforme a extensão do arquivo)."""
        caminho = Path(caminho)
        extensao = caminho.suffix.lower()
        if extensao == ".txt":
            conteudo = self.relatorio_texto()
        elif extensao == ".json":
            conteudo = json.dumps(self.relatorio_dict(), ensure_ascii=False, indent=2) + "\n"
        else:
            raise ValueError("formato de relatório não suportado: use a extensão .txt ou .json")
        caminho.write_text(conteudo, encoding="utf-8")
        return caminho
