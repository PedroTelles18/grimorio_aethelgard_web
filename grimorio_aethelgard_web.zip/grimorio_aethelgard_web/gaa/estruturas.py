"""Módulo 3 — Estrutura de dados: Tabela Hash com encadeamento separado.

Implementada do zero (sem ``dict``/``set``) para guardar o inventário de pergaminhos
auditados, indexado pelo identificador do decreto.

* Tratamento de colisões: **encadeamento separado** — cada balde é uma lista ligada.
* Função hash: DJB2 (h = h·33 + c) limitada a 32 bits, calculada em Θ(|chave|).
* Redimensionamento: ao ultrapassar o fator de carga 0,75 a capacidade passa a
  2·m + 1 e todos os nós são redistribuídos (rehash), mantendo as cadeias curtas.

Complexidades (n = nº de chaves, m = nº de baldes, α = n/m, L = |chave|):

    inserir / buscar / remover : Θ(L · (1 + α)) esperado  — O(1) amortizado com α ≤ 0,75;
                                 pior caso O(n) se todas as chaves colidirem.
    redimensionar              : Θ(n), mas ocorre a cada duplicação => custo amortizado O(1).
"""

from __future__ import annotations

from typing import Any, Callable, Iterator

FATOR_DE_CARGA_MAXIMO = 0.75


def hash_djb2(chave: str) -> int:
    """Função hash DJB2 de 32 bits para strings."""
    h = 5381
    for ch in chave:
        h = ((h << 5) + h + ord(ch)) & 0xFFFFFFFF  # h*33 + c  (mod 2^32)
    return h


class _No:
    """Nó da lista ligada de um balde."""

    __slots__ = ("chave", "valor", "proximo")

    def __init__(self, chave: str, valor: Any, proximo: "_No | None") -> None:
        self.chave = chave
        self.valor = valor
        self.proximo = proximo


class TabelaHash:
    """Mapa ``str -> valor`` com encadeamento separado e redimensionamento dinâmico."""

    def __init__(
        self,
        capacidade_inicial: int = 16,
        funcao_hash: Callable[[str], int] = hash_djb2,
    ) -> None:
        if not isinstance(capacidade_inicial, int) or capacidade_inicial < 1:
            raise ValueError("a capacidade inicial deve ser um inteiro >= 1")
        self._capacidade = capacidade_inicial
        self._baldes: list[_No | None] = [None] * capacidade_inicial
        self._tamanho = 0
        self._funcao_hash = funcao_hash

    # ------------------------------------------------------------------ #
    # Utilidades internas
    # ------------------------------------------------------------------ #
    @staticmethod
    def _checar_chave(chave: object) -> str:
        if not isinstance(chave, str):
            raise TypeError(f"a chave deve ser str, não {type(chave).__name__}")
        return chave

    def _indice(self, chave: str) -> int:
        return self._funcao_hash(chave) % self._capacidade

    def _redimensionar(self) -> None:
        nova_capacidade = 2 * self._capacidade + 1
        novos: list[_No | None] = [None] * nova_capacidade
        for cabeca in self._baldes:
            no = cabeca
            while no is not None:
                proximo = no.proximo
                idx = self._funcao_hash(no.chave) % nova_capacidade
                no.proximo = novos[idx]  # reaproveita o nó, inserindo na cabeça da nova cadeia
                novos[idx] = no
                no = proximo
        self._baldes = novos
        self._capacidade = nova_capacidade

    # ------------------------------------------------------------------ #
    # Operações principais
    # ------------------------------------------------------------------ #
    def inserir(self, chave: str, valor: Any) -> bool:
        """Insere ou atualiza. Retorna True se a chave é nova, False se atualizou."""
        self._checar_chave(chave)
        idx = self._indice(chave)
        no = self._baldes[idx]
        while no is not None:
            if no.chave == chave:
                no.valor = valor
                return False
            no = no.proximo
        self._baldes[idx] = _No(chave, valor, self._baldes[idx])  # colisão => encadeia na cabeça
        self._tamanho += 1
        if self._tamanho / self._capacidade > FATOR_DE_CARGA_MAXIMO:
            self._redimensionar()
        return True

    def buscar(self, chave: str, padrao: Any = None) -> Any:
        """Valor associado à chave, ou ``padrao`` se ela não existir."""
        self._checar_chave(chave)
        no = self._baldes[self._indice(chave)]
        while no is not None:
            if no.chave == chave:
                return no.valor
            no = no.proximo
        return padrao

    def remover(self, chave: str) -> bool:
        """Remove a chave. Retorna True se ela existia."""
        self._checar_chave(chave)
        idx = self._indice(chave)
        anterior: _No | None = None
        no = self._baldes[idx]
        while no is not None:
            if no.chave == chave:
                if anterior is None:
                    self._baldes[idx] = no.proximo
                else:
                    anterior.proximo = no.proximo
                self._tamanho -= 1
                return True
            anterior, no = no, no.proximo
        return False

    # ------------------------------------------------------------------ #
    # Protocolos Python
    # ------------------------------------------------------------------ #
    def __len__(self) -> int:
        return self._tamanho

    def __contains__(self, chave: object) -> bool:
        if not isinstance(chave, str):
            return False
        sentinela = object()
        return self.buscar(chave, sentinela) is not sentinela

    def itens(self) -> Iterator[tuple[str, Any]]:
        """Percorre todos os pares (chave, valor), em ordem arbitrária."""
        for cabeca in self._baldes:
            no = cabeca
            while no is not None:
                yield no.chave, no.valor
                no = no.proximo

    def chaves(self) -> Iterator[str]:
        for chave, _ in self.itens():
            yield chave

    # ------------------------------------------------------------------ #
    # Diagnóstico
    # ------------------------------------------------------------------ #
    def estatisticas(self) -> dict:
        """Métricas da tabela: ocupação, colisões (chaves além da 1ª em cada balde) e cadeias."""
        usados = 0
        maior = 0
        for cabeca in self._baldes:
            tam = 0
            no = cabeca
            while no is not None:
                tam += 1
                no = no.proximo
            if tam:
                usados += 1
                maior = max(maior, tam)
        return {
            "chaves": self._tamanho,
            "baldes": self._capacidade,
            "baldes_ocupados": usados,
            "fator_de_carga": round(self._tamanho / self._capacidade, 4),
            "colisoes": self._tamanho - usados,
            "maior_cadeia": maior,
        }
