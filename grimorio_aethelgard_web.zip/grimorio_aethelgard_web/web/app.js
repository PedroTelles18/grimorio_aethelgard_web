const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const api = async (u, o) => (await fetch(u, o)).json();
const post = (u, b) => api(u, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(b)});
const dorme = ms => new Promise(r => setTimeout(r, ms));
let exemplos = null;

// runas flutuantes ao fundo
const glifos = 'ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊᛏᛒᛖᛗᛚᛜᛞᛟ';
for (let i = 0; i < 26; i++) {
  const s = document.createElement('span');
  s.textContent = glifos[i % glifos.length];
  s.style.cssText = `left:${Math.random()*100}%;font-size:${18+Math.random()*34}px;animation-duration:${18+Math.random()*26}s;animation-delay:-${Math.random()*40}s`;
  $('#runas').appendChild(s);
}

function cartao(r) {
  const falhas = r.falhas.map(f => `<li>✘ <code>${f.codigo}</code> ${esc(f.mensagem)}</li>`).join('');
  return `<div class="cartao ${r.status === 'AUTENTICO' ? 'ok' : 'er'}">
    <div class="flex justify-between gap-2"><span class="id">${esc(r.identificador)}</span>
    <span class="text-xs font-semibold ${r.status === 'AUTENTICO' ? 'text-emerald-300' : 'text-red-300'}">${r.status === 'AUTENTICO' ? '✔ AUTÊNTICO' : '☠ REJEITADO'}</span></div>
    <div class="text-slate-400 text-xs mt-1">guilda ${esc(r.guilda || 'desconhecida')}${r.data ? ' · ' + r.data : ''}${r.assinatura ? ' · ' + esc(r.assinatura) : ''}</div>
    ${falhas ? `<ul>${falhas}</ul>` : ''}</div>`;
}

async function atualizar() {
  const e = await api('/api/estado'), r = e.resumo;
  $('#stats').innerHTML = [['Auditados', r.submissoes], ['Autênticos', r.autenticas], ['Fraudes', r.rejeitadas], ['No inventário', r.pergaminhos_no_inventario]]
    .map(([n, v]) => `<div class="pill"><b>${v}</b>${n}</div>`).join('');
  const max = Math.max(1, ...e.ranking.map(x => x[1]));
  $('#rank').innerHTML = e.ranking.length ? e.ranking.map(([g, n], i) =>
    `<div><div class="flex justify-between text-sm mb-1"><span class="font-rune text-gold-300">${['🥇','🥈','🥉'][i] || (i + 1) + 'º'} ${g}</span><span class="text-slate-400">${n} fraude(s)</span></div><div class="barra"><i data-w="${n / max * 100}"></i></div></div>`).join('')
    + (e.sem_guilda ? `<p class="text-xs text-slate-500">+ ${e.sem_guilda} sem guilda identificável</p>` : '')
    : '<p class="text-slate-500 text-sm">Nenhuma fraude registrada ainda.</p>';
  requestAnimationFrame(() => document.querySelectorAll('#rank .barra i').forEach(b => b.style.width = b.dataset.w + '%'));
  $('#mot').innerHTML = e.motivos.map(([c, n]) => `<span class="chip">${c} ×${n}</span>`).join('');
  const h = e.hash;
  $('#hst').textContent = `· ${h.chaves} chaves, ${h.baldes} baldes, carga ${h.fator_de_carga}, ${h.colisoes} colisões`;
  $('#ht').innerHTML = e.baldes.map(b => `<div class="bk">[${String(b.i).padStart(2, '0')}]${b.chaves.map(k => ` →<span>${esc(k)}</span>`).join('')}</div>`).join('') || '<p class="text-slate-500 text-sm">Tabela vazia.</p>';
}

$('#btnAud').onclick = async () => {
  const d = await post('/api/auditar', {texto: $('#texto').value});
  $('#res').innerHTML = d.registros.length ? d.registros.map(cartao).join('') : '<p class="text-slate-500 text-sm">Nenhum pergaminho encontrado.</p>';
  atualizar();
};
$('#btnLimpar').onclick = async () => { await post('/api/limpar', {}); $('#res').innerHTML = ''; atualizar(); };
document.querySelectorAll('[data-ex]').forEach(b => b.onclick = async () => {
  exemplos ??= await api('/api/exemplos');
  const k = b.dataset.ex;
  $('#texto').value = k === 'todos' ? exemplos.validos + '\n===\n' + exemplos.invalidos : exemplos[k];
});
$('#fBusca').onsubmit = async ev => {
  ev.preventDefault();
  const d = await api('/api/buscar?id=' + encodeURIComponent($('#bid').value));
  $('#bres').innerHTML = d.registro ? cartao(d.registro) : '<p class="text-slate-500 text-sm">Pergaminho não encontrado no inventário.</p>';
};

// ---- AFD animado ----
const Q = ['q0','q1','q2','q3'], S = ['a','b','c'];
const D = {q0:{a:'q3',b:'q1',c:'q0'}, q1:{a:'q3',b:'q1',c:'q2'}, q2:{a:'q3',b:'q1',c:'q0'}, q3:{a:'q0',b:'q3',c:'q3'}};
function tabela(de, s) {
  $('#tt').innerHTML = '<tr><th>δ</th>' + S.map(x => `<th>${x}</th>`).join('') + '</tr>' + Q.map(q =>
    `<tr><th>${q === 'q0' ? '→' : ''}${q === 'q2' ? '*' : ''}${q}</th>${S.map(x => `<td class="${de === q && s === x ? 'h' : ''}">${D[q][x]}</td>`).join('')}</tr>`).join('');
}
function marcar(q, cls = 'ativo') {
  document.querySelectorAll('.no').forEach(n => n.classList.remove('ativo', 'aceito', 'rejeitado'));
  if (q) $('#n-' + q).classList.add(cls);
}
let rodada = 0;
$('#fAfd').onsubmit = async ev => {
  ev.preventDefault();
  const id = ++rodada, d = await post('/api/afd', {palavra: $('#w').value.trim()});
  $('#afdPassos').innerHTML = ''; $('#afdRes').innerHTML = ''; tabela(); marcar('q0');
  if (d.erro) { $('#afdRes').innerHTML = `<div class="cartao er">${esc(d.erro)}</div>`; marcar(null); return; }
  for (const p of d.passos) {
    if (id !== rodada) return;
    await dorme(550);
    $('#afdPassos').insertAdjacentHTML('beforeend', `<span class="chip on">${p.de} –${p.s}→ ${p.para}</span>`);
    marcar(p.para); tabela(p.de, p.s);
  }
  marcar(d.estado_final, d.aceita ? 'aceito' : 'rejeitado');
  $('#afdRes').innerHTML = `<div class="cartao ${d.aceita ? 'ok' : 'er'}"><b>${d.aceita ? '✔ Comando aceito' : '✘ Comando rejeitado'}</b> — parou em ${d.estado_final}</div>`;
};
tabela(); marcar('q0'); atualizar();
