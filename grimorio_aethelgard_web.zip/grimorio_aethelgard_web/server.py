#!/usr/bin/env python3
"""Servidor web do GAA (somente biblioteca padrão). Uso: python server.py [porta]"""
import json, sys, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from gaa.afd import SimboloForaDoAlfabeto, criar_afd_runico
from gaa.auditor import Auditor

RAIZ = Path(__file__).parent
WEB = RAIZ / "web"
TIPOS = {".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".svg": "image/svg+xml"}
auditor = Auditor()
trava = threading.Lock()


def estado() -> dict:
    baldes = []
    for i, no in enumerate(auditor.inventario._baldes):
        cadeia = []
        while no is not None:
            cadeia.append(no.chave)
            no = no.proximo
        if cadeia:
            baldes.append({"i": i, "chaves": cadeia})
    return {
        "resumo": auditor.resumo(),
        "ranking": auditor.ranking(),
        "sem_guilda": auditor.fraudes_sem_guilda,
        "motivos": auditor.motivos(),
        "hash": auditor.inventario.estatisticas(),
        "baldes": baldes,
        "registros": [r.para_dict() for r in auditor.registros()],
    }


def rodar_afd(palavra: str) -> dict:
    try:
        r = criar_afd_runico().processar(palavra)
    except SimboloForaDoAlfabeto as e:
        return {"erro": str(e)}
    return {"aceita": r.aceita, "estado_final": r.estado_final,
            "passos": [{"s": p.simbolo, "de": p.origem, "para": p.destino} for p in r.passos]}


class Handler(BaseHTTPRequestHandler):
    def _enviar(self, corpo: bytes, tipo="application/json", status=200, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", f"{tipo}; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(corpo)

    def _json(self, obj, status=200):
        self._enviar(json.dumps(obj, ensure_ascii=False).encode(), status=status)

    def do_GET(self):
        url = urlparse(self.path)
        with trava:
            if url.path == "/api/estado":
                return self._json(estado())
            if url.path == "/api/buscar":
                r = auditor.buscar(parse_qs(url.query).get("id", [""])[0])
                return self._json({"registro": r.para_dict() if r else None})
            if url.path == "/api/exemplos":
                ler = lambda n: (RAIZ / "exemplos" / n).read_text(encoding="utf-8")
                return self._json({"validos": ler("decretos_validos.txt"), "invalidos": ler("decretos_invalidos.txt")})
            if url.path == "/api/relatorio.json":
                c = json.dumps(auditor.relatorio_dict(), ensure_ascii=False, indent=2)
                return self._enviar(c.encode(), extra={"Content-Disposition": "attachment; filename=relatorio.json"})
            if url.path == "/api/relatorio.txt":
                return self._enviar(auditor.relatorio_texto().encode(), "text/plain",
                                    extra={"Content-Disposition": "attachment; filename=relatorio.txt"})
        alvo = (WEB / ("index.html" if url.path == "/" else url.path.lstrip("/"))).resolve()
        if WEB.resolve() in alvo.parents and alvo.is_file():
            return self._enviar(alvo.read_bytes(), TIPOS.get(alvo.suffix, "application/octet-stream"))
        self._enviar(b"404", "text/plain", 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        try:
            dados = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            return self._json({"erro": "JSON inválido"}, 400)
        global auditor
        with trava:
            if self.path == "/api/auditar":
                regs = auditor.auditar_texto(str(dados.get("texto", "")))
                return self._json({"registros": [r.para_dict() for r in regs]})
            if self.path == "/api/limpar":
                auditor = Auditor()
                return self._json({"ok": True})
            if self.path == "/api/afd":
                return self._json(rodar_afd(str(dados.get("palavra", ""))))
        self._json({"erro": "rota inexistente"}, 404)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    srv = ThreadingHTTPServer(("127.0.0.1", porta), Handler)
    url = f"http://127.0.0.1:{porta}"
    print(f"Grimório de Aethelgard no ar: {url}  (Ctrl+C para sair)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")
