#!/usr/bin/env python3
"""Ponto de entrada do Grimório Automático de Auditoria (GAA).

Exemplos:
    python main.py demo
    python main.py auditar exemplos/decretos_validos.txt exemplos/decretos_invalidos.txt -r relatorio.json
    python main.py afd abbcabc --passos
    python main.py interativo exemplos/decretos_validos.txt
"""

import sys

from gaa.cli import main

if __name__ == "__main__":
    sys.exit(main())
