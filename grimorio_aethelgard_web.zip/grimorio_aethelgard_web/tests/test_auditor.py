"""Testes de integração do Auditor: Regex + AFD + Tabela Hash + relatórios."""

import json
import re
import sys
import tempfile
import unicodedata
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from gaa.auditor import Auditor
from gaa.modelos import (
    E_CORPO_AFD,
    E_CORPO_ALFABETO,
    E_ESTRUTURA,
    STATUS_AUTENTICO,
    STATUS_REJEITADO,
)
from gaa.pergaminho import (
    ErroLeituraPergaminho,
    dividir_pergaminhos,
    ler_arquivo,
    separar_cabecalho_corpo,
)

EXEMPLOS = RAIZ / "exemplos"


def pergaminho(id_="ALQ-10492", data="15/03/2043", assin="[Mestre Alabaster]", corpo="bc"):
    return f"{id_}\nSelado em {data}\n{assin}\n---\n{corpo}"


def codigos(registro):
    return {f.codigo for f in registro.falhas}


class TestPergaminhoArquivo(unittest.TestCase):
    def test_divisao_em_pergaminhos(self):
        texto = "# cabeçalho\n\n" + pergaminho("AAA-1111") + "\n===\n" + pergaminho("BBB-2222") + "\n===\n"
        self.assertEqual(len(dividir_pergaminhos(texto)), 2)

    def test_separacao_cabecalho_corpo(self):
        cab, corpo, achou = separar_cabecalho_corpo(pergaminho(corpo="abc"))
        self.assertTrue(achou)
        self.assertTrue(cab.startswith("ALQ-10492"))
        self.assertEqual(corpo, "abc")
        self.assertFalse(separar_cabecalho_corpo("ALQ-10492\n15/03/2043")[2])

    def test_arquivo_inexistente(self):
        with self.assertRaises(ErroLeituraPergaminho):
            ler_arquivo(RAIZ / "nao_existe.txt")

    def test_diretorio_e_codificacao_invalida(self):
        with self.assertRaises(ErroLeituraPergaminho):
            ler_arquivo(RAIZ)
        with tempfile.TemporaryDirectory() as d:
            ruim = Path(d) / "latin1.txt"
            ruim.write_bytes("Álvaro".encode("latin-1"))
            with self.assertRaises(ErroLeituraPergaminho):
                ler_arquivo(ruim)


class TestAuditoriaIndividual(unittest.TestCase):
    def setUp(self):
        self.aud = Auditor()

    def test_pergaminho_autentico(self):
        r = self.aud.auditar_pergaminho(pergaminho(corpo="abbcabc"))
        self.assertEqual(r.status, STATUS_AUTENTICO)
        self.assertEqual(r.falhas, [])
        self.assertEqual((r.guilda, r.data, r.assinatura), ("ALQ", "15/03/2043", "Mestre Alabaster"))

    def test_rejeicao_pelo_afd_com_motivo(self):
        impar = self.aud.auditar_pergaminho(pergaminho("AAA-1111", corpo="abc"))
        self.assertEqual(codigos(impar), {E_CORPO_AFD})
        self.assertIn("ímpar", impar.falhas[0].mensagem)
        par = self.aud.auditar_pergaminho(pergaminho("AAA-2222", corpo="aabcc"))
        self.assertEqual(codigos(par), {E_CORPO_AFD})
        self.assertIn("não termina com 'bc'", par.falhas[0].mensagem)

    def test_simbolo_fora_do_alfabeto(self):
        r = self.aud.auditar_pergaminho(pergaminho(corpo="abdbc"))
        self.assertEqual(codigos(r), {E_CORPO_ALFABETO})
        self.assertIn("'d'", r.falhas[0].mensagem)

    def test_corpo_com_espaco_ou_quebra_interna_e_rejeitado(self):
        for corpo in ("ab c", "ab\nbc"):
            with self.subTest(corpo):
                r = self.aud.auditar_pergaminho(pergaminho(corpo=corpo))
                self.assertEqual(codigos(r), {E_CORPO_ALFABETO})

    def test_espacos_nas_pontas_do_corpo_sao_toleraveis(self):
        r = self.aud.auditar_pergaminho(pergaminho(corpo="  \nabbcabc\n\n  "))
        self.assertTrue(r.autentico)

    def test_afd_nao_roda_se_cabecalho_falhou(self):
        # Cabeçote inválido + corpo inválido: apenas as falhas do cabeçote são reportadas.
        r = self.aud.auditar_pergaminho(pergaminho("ALQ-1", corpo="abx"))
        self.assertEqual(codigos(r), {"E_ID"})

    def test_sem_separador(self):
        r = self.aud.auditar_pergaminho("ALQ-10492\n15/03/2043\n[Mestre Alabaster]\nbc")
        self.assertEqual(codigos(r), {E_ESTRUTURA})

    def test_cabecalho_vazio_gera_chave_sintetica(self):
        r1 = self.aud.auditar_pergaminho("---\nbc")
        r2 = self.aud.auditar_pergaminho("---\nbc")
        self.assertEqual(r1.identificador, "<SEM-ID-1>")
        self.assertEqual(r2.identificador, "<SEM-ID-2>")
        self.assertEqual(self.aud.fraudes_sem_guilda, 2)

    def test_linhas_crlf(self):
        texto = pergaminho(corpo="abbcabc").replace("\n", "\r\n")
        self.assertTrue(self.aud.auditar_pergaminho(texto).autentico)

    def test_assinatura_unicode_decomposta(self):
        texto = unicodedata.normalize("NFD", pergaminho(assin="[Álvaro de Thornwood]"))
        self.assertTrue(self.aud.auditar_pergaminho(texto).autentico)


class TestInventarioEBusca(unittest.TestCase):
    def setUp(self):
        self.aud = Auditor()

    def test_busca_por_identificador(self):
        self.aud.auditar_pergaminho(pergaminho("ALQ-10492"))
        self.aud.auditar_pergaminho(pergaminho("FOR-2048", corpo="abc"))
        self.assertEqual(self.aud.buscar("ALQ-10492").status, STATUS_AUTENTICO)
        self.assertEqual(self.aud.buscar("  FOR-2048 ").status, STATUS_REJEITADO)
        self.assertIsNone(self.aud.buscar("MAG-0000"))

    def test_pergaminho_rejeitado_com_id_invalido_tambem_e_consultavel(self):
        self.aud.auditar_pergaminho(pergaminho("ALQ-12"))
        r = self.aud.buscar("ALQ-12")
        self.assertIsNotNone(r)
        self.assertEqual(r.guilda, "ALQ")
        self.assertEqual(codigos(r), {"E_ID"})

    def test_reauditoria_atualiza_e_conta(self):
        self.aud.auditar_pergaminho(pergaminho("ALQ-10492", corpo="abc"))     # rejeitado
        self.aud.auditar_pergaminho(pergaminho("ALQ-10492", corpo="aabc"))    # corrigido
        r = self.aud.buscar("ALQ-10492")
        self.assertEqual(r.status, STATUS_AUTENTICO)
        self.assertEqual(r.auditorias, 2)
        self.assertEqual(len(self.aud.inventario), 1)
        resumo = self.aud.resumo()
        self.assertEqual((resumo["submissoes"], resumo["autenticas"], resumo["rejeitadas"]), (2, 1, 1))
        self.assertEqual(self.aud.ranking(), [("ALQ", 1)])  # a tentativa anterior continua registrada

    def test_inventario_grande_com_colisoes_e_redimensionamento(self):
        aud = Auditor(capacidade_inicial=2)
        for i in range(3000):
            guilda = "ABCDEFGHIJ"[i % 10] * 3
            corpo = "bc" if i % 3 else "abc"
            aud.auditar_pergaminho(pergaminho(f"{guilda}-{1000 + i}", corpo=corpo))
        self.assertEqual(len(aud.inventario), 3000)
        for i in range(3000):
            guilda = "ABCDEFGHIJ"[i % 10] * 3
            r = aud.buscar(f"{guilda}-{1000 + i}")
            self.assertEqual(r.autentico, bool(i % 3))
        self.assertLessEqual(aud.inventario.estatisticas()["fator_de_carga"], 0.75)
        self.assertEqual(sum(n for _, n in aud.ranking()), 1000)


class TestSuiteDeExemplos(unittest.TestCase):
    def test_todos_os_validos_sao_autenticos(self):
        aud = Auditor()
        registros = aud.auditar_arquivo(EXEMPLOS / "decretos_validos.txt")
        self.assertEqual(len(registros), 7)
        for r in registros:
            self.assertTrue(r.autentico, r)

    def test_invalidos_geram_exatamente_os_codigos_esperados(self):
        texto = ler_arquivo(EXEMPLOS / "decretos_invalidos.txt")
        blocos = dividir_pergaminhos(texto)
        self.assertGreaterEqual(len(blocos), 30)
        cobertos = set()
        for bloco in blocos:
            m = re.search(r"^#\s*ESPERADO:\s*(.+)$", bloco, re.MULTILINE)
            self.assertIsNotNone(m, f"bloco sem '# ESPERADO:':\n{bloco}")
            esperado = set(m.group(1).split())
            registro = Auditor().auditar_pergaminho(bloco)
            self.assertEqual(registro.status, STATUS_REJEITADO, bloco)
            self.assertEqual(codigos(registro), esperado, bloco)
            cobertos |= esperado
        # Todos os tipos de fraude previstos aparecem na suíte.
        self.assertEqual(
            cobertos,
            {"E_ID", "E_DATA", "E_DATA_INEXISTENTE", "E_ASSINATURA", "E_CORPO_AFD", "E_CORPO_ALFABETO", "E_ESTRUTURA"},
        )

    def test_ranking_dos_exemplos(self):
        aud = Auditor()
        aud.auditar_arquivo(EXEMPLOS / "decretos_validos.txt")
        aud.auditar_arquivo(EXEMPLOS / "decretos_invalidos.txt")
        self.assertEqual(
            aud.ranking(),
            [("COM", 7), ("FOR", 7), ("ARC", 6), ("ALQ", 3), ("MAG", 2), ("TEC", 1), ("XYZ", 1)],
        )
        self.assertEqual(aud.fraudes_sem_guilda, 5)
        resumo = aud.resumo()
        self.assertEqual((resumo["submissoes"], resumo["autenticas"], resumo["rejeitadas"]), (39, 7, 32))


class TestRelatorios(unittest.TestCase):
    def setUp(self):
        self.aud = Auditor()
        self.aud.auditar_arquivo(EXEMPLOS / "decretos_validos.txt")
        self.aud.auditar_arquivo(EXEMPLOS / "decretos_invalidos.txt")
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_relatorio_txt(self):
        destino = Path(self.tmp.name) / "relatorio.txt"
        self.aud.gerar_relatorio(destino)
        texto = destino.read_text(encoding="utf-8")
        self.assertIn("RANKING DE GUILDAS", texto)
        linhas = [ln for ln in texto.splitlines() if re.match(r"^\d+\s+[A-Z]{3}\s", ln)]
        self.assertEqual(linhas[0].split()[1:], ["COM", "7"])
        self.assertEqual(len(linhas), 7)

    def test_relatorio_json(self):
        destino = Path(self.tmp.name) / "relatorio.json"
        self.aud.gerar_relatorio(destino)
        dados = json.loads(destino.read_text(encoding="utf-8"))
        self.assertEqual(dados["resumo"]["rejeitadas"], 32)
        self.assertEqual(dados["ranking_guildas"][0], {"posicao": 1, "guilda": "COM", "tentativas_de_fraude": 7})
        self.assertEqual(dados["tentativas_sem_guilda_identificada"], 5)
        self.assertEqual(len(dados["pergaminhos_rejeitados"]), 32)
        self.assertIn("E_ID", dados["motivos_de_rejeicao"])

    def test_extensao_nao_suportada(self):
        with self.assertRaises(ValueError):
            self.aud.gerar_relatorio(Path(self.tmp.name) / "relatorio.pdf")

    def test_relatorio_sem_fraudes(self):
        aud = Auditor()
        aud.auditar_pergaminho(pergaminho())
        texto = aud.relatorio_texto()
        self.assertIn("nenhuma tentativa de fraude", texto)
        self.assertEqual(aud.relatorio_dict()["ranking_guildas"], [])


if __name__ == "__main__":
    unittest.main()
