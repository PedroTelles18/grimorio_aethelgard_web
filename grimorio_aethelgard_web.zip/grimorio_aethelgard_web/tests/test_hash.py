"""Testes do Módulo 3 — Tabela Hash com encadeamento separado."""

import random
import string
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gaa.estruturas import FATOR_DE_CARGA_MAXIMO, TabelaHash, hash_djb2


class TestTabelaHashBasica(unittest.TestCase):
    def test_inserir_e_buscar(self):
        t = TabelaHash()
        self.assertTrue(t.inserir("ALQ-10492", "autêntico"))
        self.assertEqual(t.buscar("ALQ-10492"), "autêntico")
        self.assertIn("ALQ-10492", t)
        self.assertEqual(len(t), 1)

    def test_busca_de_chave_inexistente(self):
        t = TabelaHash()
        self.assertIsNone(t.buscar("XXX-0000"))
        self.assertEqual(t.buscar("XXX-0000", "padrão"), "padrão")
        self.assertNotIn("XXX-0000", t)

    def test_atualizacao_nao_duplica(self):
        t = TabelaHash()
        self.assertTrue(t.inserir("k", 1))
        self.assertFalse(t.inserir("k", 2))
        self.assertEqual(t.buscar("k"), 2)
        self.assertEqual(len(t), 1)

    def test_valor_none_e_distinguivel_de_ausente(self):
        t = TabelaHash()
        t.inserir("k", None)
        self.assertIn("k", t)

    def test_remocao(self):
        t = TabelaHash()
        for i in range(10):
            t.inserir(f"k{i}", i)
        self.assertTrue(t.remover("k3"))
        self.assertFalse(t.remover("k3"))
        self.assertNotIn("k3", t)
        self.assertEqual(len(t), 9)
        self.assertEqual(t.buscar("k4"), 4)

    def test_chave_deve_ser_str(self):
        t = TabelaHash()
        for ruim in (123, None, ("a",), b"x"):
            with self.subTest(ruim), self.assertRaises(TypeError):
                t.inserir(ruim, 1)
            with self.subTest(ruim), self.assertRaises(TypeError):
                t.buscar(ruim)
        self.assertNotIn(123, t)

    def test_capacidade_invalida(self):
        for ruim in (0, -3, 2.5, None):
            with self.subTest(ruim), self.assertRaises(ValueError):
                TabelaHash(ruim)

    def test_chave_vazia_e_unicode(self):
        t = TabelaHash()
        t.inserir("", "vazia")
        t.inserir("ÁLQ-ç", "unicode")
        self.assertEqual(t.buscar(""), "vazia")
        self.assertEqual(t.buscar("ÁLQ-ç"), "unicode")

    def test_hash_djb2_deterministico_e_32_bits(self):
        self.assertEqual(hash_djb2(""), 5381)
        self.assertEqual(hash_djb2("a"), 5381 * 33 + ord("a"))
        self.assertEqual(hash_djb2("ALQ-10492"), hash_djb2("ALQ-10492"))
        self.assertLess(hash_djb2("x" * 1000), 2**32)


class TestColisoes(unittest.TestCase):
    def test_todas_as_chaves_colidindo(self):
        """Função hash constante: tudo cai no mesmo balde; a estrutura continua correta."""
        t = TabelaHash(4, funcao_hash=lambda _: 7)
        for i in range(200):
            t.inserir(f"chave-{i}", i)
        self.assertEqual(len(t), 200)
        for i in range(200):
            self.assertEqual(t.buscar(f"chave-{i}"), i)
        e = t.estatisticas()
        self.assertEqual(e["baldes_ocupados"], 1)
        self.assertEqual(e["maior_cadeia"], 200)
        self.assertEqual(e["colisoes"], 199)

    def test_remocao_em_cadeia_cabeca_meio_e_cauda(self):
        t = TabelaHash(1, funcao_hash=lambda _: 0)
        # Capacidade 1 cresce ao inserir, mas a função constante mantém tudo em 1 cadeia.
        for k in ["a", "b", "c", "d", "e"]:
            t.inserir(k, k.upper())
        for k in ["e", "c", "a"]:      # cabeça (último inserido), meio e cauda
            self.assertTrue(t.remover(k))
        self.assertEqual(sorted(t.chaves()), ["b", "d"])
        self.assertEqual(t.buscar("b"), "B")
        self.assertEqual(t.buscar("d"), "D")

    def test_colisao_real_com_hash_curto(self):
        t = TabelaHash(8, funcao_hash=lambda s: len(s))  # strings de mesmo tamanho colidem
        for chave in ["aa", "bb", "cc", "dd"]:
            t.inserir(chave, chave)
        for chave in ["aa", "bb", "cc", "dd"]:
            self.assertEqual(t.buscar(chave), chave)
        self.assertGreaterEqual(t.estatisticas()["colisoes"], 3)


class TestRedimensionamento(unittest.TestCase):
    def test_mantem_fator_de_carga_e_dados(self):
        t = TabelaHash(2)
        for i in range(1000):
            t.inserir(f"FOR-{i:06d}", i)
            self.assertLessEqual(len(t) / t.estatisticas()["baldes"], FATOR_DE_CARGA_MAXIMO + 1e-9)
        self.assertEqual(len(t), 1000)
        self.assertGreater(t.estatisticas()["baldes"], 2)
        for i in range(1000):
            self.assertEqual(t.buscar(f"FOR-{i:06d}"), i)

    def test_itens_percorre_tudo_uma_vez(self):
        t = TabelaHash(2)
        esperado = {f"k{i}": i for i in range(300)}
        for k, v in esperado.items():
            t.inserir(k, v)
        self.assertEqual(dict(t.itens()), esperado)
        self.assertEqual(len(list(t.itens())), 300)


class TestContraDicionario(unittest.TestCase):
    def test_operacoes_aleatorias_equivalem_a_dict(self):
        rng = random.Random(20261029)
        t = TabelaHash(3)
        ref: dict[str, int] = {}
        alfabeto = string.ascii_uppercase[:5] + "-" + string.digits[:4]
        for passo in range(20000):
            chave = "".join(rng.choice(alfabeto) for _ in range(rng.randint(0, 4)))
            op = rng.random()
            if op < 0.55:
                novo = chave not in ref
                self.assertEqual(t.inserir(chave, passo), novo)
                ref[chave] = passo
            elif op < 0.80:
                self.assertEqual(t.remover(chave), chave in ref)
                ref.pop(chave, None)
            else:
                self.assertEqual(t.buscar(chave, "AUSENTE"), ref.get(chave, "AUSENTE"))
            self.assertEqual(len(t), len(ref))
        self.assertEqual(dict(t.itens()), ref)


class TestDistribuicao(unittest.TestCase):
    def test_djb2_distribui_ids_sequenciais(self):
        t = TabelaHash()
        for i in range(5000):
            t.inserir(f"ALQ-{i:05d}", i)
        e = t.estatisticas()
        # Com boa dispersão a maior cadeia fica pequena (muito abaixo de n).
        self.assertLess(e["maior_cadeia"], 20)
        self.assertLessEqual(e["fator_de_carga"], FATOR_DE_CARGA_MAXIMO)


if __name__ == "__main__":
    unittest.main()
