"""Testes da CLI executando main.py como o usuário faria (subprocess)."""

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
MAIN = str(RAIZ / "main.py")
EXEMPLOS = RAIZ / "exemplos"


def rodar(*args, entrada=None):
    return subprocess.run(
        [sys.executable, MAIN, *args],
        input=entrada,
        capture_output=True,
        text=True,
        encoding="utf-8",
        cwd=RAIZ,
        timeout=60,
    )


class TestCLI(unittest.TestCase):
    def test_demo(self):
        p = rodar("demo")
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn("[AUTENTICO]  ALQ-10492", p.stdout)
        self.assertIn("Ranking de guildas", p.stdout)

    def test_auditar_com_busca_e_relatorios(self):
        with tempfile.TemporaryDirectory() as d:
            saida_json = Path(d) / "rel.json"
            saida_txt = Path(d) / "rel.txt"
            for saida in (saida_json, saida_txt):
                p = rodar(
                    "auditar", str(EXEMPLOS / "decretos_validos.txt"), str(EXEMPLOS / "decretos_invalidos.txt"),
                    "--buscar", "FOR-3002", "--buscar", "NAO-0000", "-r", str(saida), "--resumido",
                )
                self.assertEqual(p.returncode, 0, p.stderr)
                self.assertTrue(saida.exists())
            self.assertIn("pergaminho não encontrado", p.stdout)
            self.assertIn("E_DATA", p.stdout)
            self.assertEqual(json.loads(saida_json.read_text(encoding="utf-8"))["ranking_guildas"][0]["guilda"], "COM")

    def test_arquivo_inexistente(self):
        p = rodar("auditar", "nao_existe.txt")
        self.assertEqual(p.returncode, 1)
        self.assertIn("arquivo não encontrado", p.stderr)

    def test_extensao_de_relatorio_invalida(self):
        p = rodar("auditar", str(EXEMPLOS / "decretos_validos.txt"), "-r", "saida.pdf")
        self.assertEqual(p.returncode, 1)
        self.assertIn("não foi possível gerar o relatório", p.stderr)

    def test_afd(self):
        aceita = rodar("afd", "abbcabc", "--passos", "--tabela")
        self.assertEqual(aceita.returncode, 0)
        self.assertIn("ACEITA", aceita.stdout)
        self.assertIn("δ(q0, a) = q3", aceita.stdout)
        self.assertIn("M = (Q, Σ, δ, q0, F)", aceita.stdout)

        rejeita = rodar("afd", "abc")
        self.assertEqual(rejeita.returncode, 1)
        self.assertIn("REJEITADA", rejeita.stdout)

        vazia = rodar("afd", "")
        self.assertEqual(vazia.returncode, 1)

        fora = rodar("afd", "abxbc")
        self.assertEqual(fora.returncode, 1)
        self.assertIn("não pertence ao alfabeto", fora.stdout)

    def test_modo_interativo(self):
        script = "\n".join([
            f"carregar {EXEMPLOS / 'decretos_validos.txt'} {EXEMPLOS / 'decretos_invalidos.txt'}",
            "buscar ALQ-10492",
            "buscar FOR-3001",
            "buscar ZZZ-0000",
            "ranking",
            "afd bc",
            "estatisticas",
            "comando-inexistente",
            "carregar nao_existe.txt",
            "sair",
        ]) + "\n"
        p = rodar("interativo", entrada=script)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn("[AUTENTICO]  ALQ-10492", p.stdout)
        self.assertIn("[REJEITADO]  FOR-3001", p.stdout)
        self.assertIn("pergaminho não encontrado", p.stdout)
        self.assertIn("COM  7 tentativa(s)", p.stdout)
        self.assertIn("ACEITA", p.stdout)
        self.assertIn("fator_de_carga", p.stdout)
        self.assertIn("comando desconhecido", p.stdout)
        self.assertIn("arquivo não encontrado", p.stderr)

    def test_interativo_termina_com_eof(self):
        p = rodar("interativo", entrada="")
        self.assertEqual(p.returncode, 0)


if __name__ == "__main__":
    unittest.main()
