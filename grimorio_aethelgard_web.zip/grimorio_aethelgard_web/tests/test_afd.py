"""Testes do Módulo 2 — Autômato Finito Determinístico."""

import itertools
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gaa.afd import AFD, AutomatoInvalido, SimboloForaDoAlfabeto, criar_afd_runico


def referencia(palavra: str) -> bool:
    """Definição direta da linguagem L: nº par de 'a' e termina com 'bc'."""
    return palavra.count("a") % 2 == 0 and palavra.endswith("bc")


class TestAFDRunico(unittest.TestCase):
    def setUp(self):
        self.afd = criar_afd_runico()

    def test_definicao_formal(self):
        self.assertEqual(self.afd.estados, ("q0", "q1", "q2", "q3"))
        self.assertEqual(self.afd.alfabeto, ("a", "b", "c"))
        self.assertEqual(self.afd.inicial, "q0")
        self.assertEqual(self.afd.finais, frozenset({"q2"}))
        self.assertEqual(len(self.afd.delta), 4 * 3)  # função total: |Q|·|Σ| transições

    def test_exemplos_aceitos(self):
        for palavra in ["bc", "abbcabc", "aabc", "cbcbc", "abcabcbc", "aaaabc", "cccbc", "bcbc", "abacbc"]:
            with self.subTest(palavra):
                self.assertTrue(self.afd.aceita(palavra))

    def test_exemplos_rejeitados(self):
        casos = {
            "": "palavra vazia não termina em bc",
            "a": "ímpar",
            "abc": "ímpar de a, termina em bc",
            "aabcc": "par, termina em cc",
            "abca": "ímpar",
            "b": "sem c",
            "c": "sem b",
            "cb": "termina em cb",
            "aabcb": "termina em cb",
            "bca": "ímpar de a e termina em a",
            "bcaa": "par, mas termina em aa",
        }
        for palavra in casos:
            with self.subTest(palavra):
                self.assertFalse(self.afd.aceita(palavra))
        # 2 símbolos 'a' (par) e termina em "bc": aceita.
        self.assertTrue(self.afd.aceita("abcabc"))

    def test_equivalencia_exaustiva_ate_comprimento_10(self):
        """Compara o AFD com a definição da linguagem em TODAS as 88.573 palavras até |w| = 10."""
        total = 0
        for n in range(0, 11):
            for tupla in itertools.product("abc", repeat=n):
                palavra = "".join(tupla)
                self.assertEqual(self.afd.aceita(palavra), referencia(palavra), palavra)
                total += 1
        self.assertEqual(total, sum(3**n for n in range(11)))

    def test_invariante_dos_estados(self):
        """Após ler u: q3 ⇔ #a ímpar; senão q2 ⇔ termina em 'bc', q1 ⇔ termina em 'b', q0 caso contrário."""
        for n in range(0, 9):
            for tupla in itertools.product("abc", repeat=n):
                u = "".join(tupla)
                esperado = (
                    "q3" if u.count("a") % 2
                    else "q2" if u.endswith("bc")
                    else "q1" if u.endswith("b")
                    else "q0"
                )
                self.assertEqual(self.afd.processar(u).estado_final, esperado, u)

    def test_trace_de_passos(self):
        res = self.afd.processar("abc")
        self.assertEqual([(p.simbolo, p.origem, p.destino) for p in res.passos],
                         [("a", "q0", "q3"), ("b", "q3", "q3"), ("c", "q3", "q3")])
        self.assertEqual(res.estado_final, "q3")
        self.assertFalse(res.aceita)

    def test_simbolo_fora_do_alfabeto(self):
        with self.assertRaises(SimboloForaDoAlfabeto) as ctx:
            self.afd.processar("abxbc")
        self.assertEqual(ctx.exception.simbolo, "x")
        self.assertEqual(ctx.exception.posicao, 2)
        for ruim in ["ABC", "a b", "bc\n", "bç", "ab1"]:
            with self.subTest(ruim), self.assertRaises(SimboloForaDoAlfabeto):
                self.afd.processar(ruim)

    def test_automato_e_minimo(self):
        self.assertEqual(self.afd.numero_de_estados_minimo(), 4)

    def test_minimizacao_detecta_estados_redundantes(self):
        """Um AFD com estado duplicado deve ser reduzido pela minimização."""
        delta = {
            ("p", "0"): "q", ("p", "1"): "p",
            ("q", "0"): "r", ("q", "1"): "q",   # q e r são equivalentes (ambos não aceitam e se comportam igual)
            ("r", "0"): "r", ("r", "1"): "q",
        }
        afd = AFD(("p", "q", "r"), ("0", "1"), delta, "p", {"r", "q"})
        self.assertLess(afd.numero_de_estados_minimo(), 3)

    def test_dot_e_tabela(self):
        dot = self.afd.para_dot()
        self.assertIn("digraph", dot)
        self.assertIn("q2 [shape=doublecircle]", dot)
        self.assertIn("__inicio -> q0", dot)
        tabela = self.afd.tabela_transicao()
        self.assertIn("->", tabela)
        self.assertIn("*", tabela)
        self.assertIn("M = (Q, Σ, δ, q0, F)", self.afd.descricao_formal())


class TestValidacaoDeDefinicao(unittest.TestCase):
    def test_delta_parcial_e_recusada(self):
        with self.assertRaises(AutomatoInvalido):
            AFD(("p",), ("0", "1"), {("p", "0"): "p"}, "p", {"p"})

    def test_estado_inicial_fora_de_q(self):
        with self.assertRaises(AutomatoInvalido):
            AFD(("p",), ("0",), {("p", "0"): "p"}, "zzz", set())

    def test_finais_fora_de_q(self):
        with self.assertRaises(AutomatoInvalido):
            AFD(("p",), ("0",), {("p", "0"): "p"}, "p", {"zzz"})

    def test_destino_desconhecido(self):
        with self.assertRaises(AutomatoInvalido):
            AFD(("p",), ("0",), {("p", "0"): "zzz"}, "p", set())


if __name__ == "__main__":
    unittest.main()
