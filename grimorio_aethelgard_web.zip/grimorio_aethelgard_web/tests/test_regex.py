"""Testes do Módulo 1 — Expressões Regulares (cabeçote do pergaminho)."""

import sys
import unicodedata
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from gaa.modelos import E_ASSINATURA, E_DATA, E_DATA_INEXISTENTE, E_ESTRUTURA, E_ID
from gaa.regex_validador import (
    PADRAO_ASSINATURA,
    PADRAO_DATA,
    PADRAO_ID,
    data_existe,
    extrair_guilda,
    validar_cabecalho,
)


def cab(id_="ALQ-10492", data="15/03/2043", assin="[Mestre Alabaster]"):
    return f"{id_}\nSelado em {data}\n{assin}"


def codigos(res):
    return [f.codigo for f in res.falhas]


class TestIdentificador(unittest.TestCase):
    def test_validos(self):
        for texto in ["ALQ-10492", "FOR-2048", "MAG-998877", "COM-0001", "ARC-123456"]:
            with self.subTest(texto):
                self.assertIsNotNone(PADRAO_ID.fullmatch(texto))

    def test_invalidos(self):
        casos = [
            "ALQ-123",        # 3 dígitos
            "ALQ-1234567",    # 7 dígitos
            "AL-10492",       # 2 letras
            "ALQU-10492",     # 4 letras
            "alq-10492",      # minúsculas
            "Alq-10492",      # misto
            "ALQ10492",       # sem hífen
            "ALQ_10492",      # sublinhado
            "ALQ-10A92",      # letra no número
            "ÁLQ-10492",      # letra acentuada
            "ALQ-١٠٤٩٢",      # dígitos arábico-índicos (\d do Python aceitaria!)
            "ALQ-10492 ",     # espaço sobrando
            " ALQ-10492",
            "",
        ]
        for texto in casos:
            with self.subTest(texto):
                self.assertIsNone(PADRAO_ID.fullmatch(texto))

    def test_fronteiras_de_digitos(self):
        self.assertIsNotNone(PADRAO_ID.fullmatch("ABC-1234"))      # mínimo
        self.assertIsNotNone(PADRAO_ID.fullmatch("ABC-123456"))    # máximo
        self.assertIsNone(PADRAO_ID.fullmatch("ABC-12345678"))

    def test_extrair_guilda_de_id_invalido(self):
        self.assertEqual(extrair_guilda("ALQ-123"), "ALQ")
        self.assertIsNone(extrair_guilda("ALQU-10492"))
        self.assertIsNone(extrair_guilda("alq-10492"))
        self.assertIsNone(extrair_guilda("ALQ10492"))


class TestData(unittest.TestCase):
    def test_validas(self):
        for texto in ["01/01/2000", "31/12/2099", "15/03/2043", "29/02/2040", "10/10/2077"]:
            with self.subTest(texto):
                self.assertIsNotNone(PADRAO_DATA.search(texto))

    def test_invalidas(self):
        casos = [
            "15/3/2043",       # mês com 1 dígito
            "5/03/2043",       # dia com 1 dígito
            "15/03/43",        # ano com 2 dígitos
            "15/03/1999",      # antes da Terceira Era
            "15/03/2100",      # depois da Terceira Era
            "00/03/2043",      # dia 00
            "32/03/2043",      # dia 32
            "15/00/2043",      # mês 00
            "15/13/2043",      # mês 13
            "15/03/20431",     # dígito sobrando
            "115/03/2043",     # dígito sobrando à esquerda
            "2043-03-15",      # ISO
            "15-03-2043",      # separador errado
        ]
        for texto in casos:
            with self.subTest(texto):
                self.assertIsNone(PADRAO_DATA.search(texto))

    def test_calendario(self):
        self.assertTrue(data_existe(29, 2, 2024))
        self.assertTrue(data_existe(29, 2, 2000))   # 2000 é bissexto (divisível por 400)
        self.assertFalse(data_existe(29, 2, 2043))
        self.assertFalse(data_existe(31, 2, 2050))
        self.assertFalse(data_existe(31, 4, 2050))
        self.assertTrue(data_existe(31, 12, 2099))


class TestAssinatura(unittest.TestCase):
    def test_validas(self):
        for texto in ["[Mestre Alabaster]", "[Ordem]", "[Álvaro de Thornwood]", "[" + "a" * 40 + "]"]:
            with self.subTest(texto):
                self.assertIsNotNone(PADRAO_ASSINATURA.fullmatch(texto))

    def test_invalidas(self):
        casos = [
            "[Mago]",                  # 4 caracteres
            "[" + "a" * 41 + "]",      # 41 caracteres
            "[Mestre 3 Alabaster]",    # número
            "[Mestre_Alabaster]",      # sublinhado
            "[Mestre-Alabaster]",      # hífen
            "[Mestre.Alabaster]",      # ponto
            "[      ]",                # só espaços
            "[]",
            "Mestre Alabaster",        # sem colchetes
            "[Mestre Alabaster",       # colchete aberto
        ]
        for texto in casos:
            with self.subTest(texto):
                self.assertIsNone(PADRAO_ASSINATURA.fullmatch(texto))

    def test_limites_exatos(self):
        self.assertIsNotNone(PADRAO_ASSINATURA.fullmatch("[" + "a" * 5 + "]"))
        self.assertIsNone(PADRAO_ASSINATURA.fullmatch("[" + "a" * 4 + "]"))
        self.assertIsNotNone(PADRAO_ASSINATURA.fullmatch("[" + "a" * 40 + "]"))
        self.assertIsNone(PADRAO_ASSINATURA.fullmatch("[" + "a" * 41 + "]"))


class TestCabecalhoCompleto(unittest.TestCase):
    def test_cabecalho_valido(self):
        res = validar_cabecalho(cab())
        self.assertTrue(res.valido)
        self.assertEqual(res.identificador, "ALQ-10492")
        self.assertEqual(res.guilda, "ALQ")
        self.assertEqual(res.data, "15/03/2043")
        self.assertEqual(res.assinatura, "Mestre Alabaster")

    def test_cada_falha_isolada(self):
        self.assertEqual(codigos(validar_cabecalho(cab(id_="ALQ-12"))), [E_ID])
        self.assertEqual(codigos(validar_cabecalho(cab(data="15/03/1999"))), [E_DATA])
        self.assertEqual(codigos(validar_cabecalho(cab(data="31/02/2050"))), [E_DATA_INEXISTENTE])
        self.assertEqual(codigos(validar_cabecalho(cab(assin="[Mago]"))), [E_ASSINATURA])

    def test_falhas_acumuladas(self):
        res = validar_cabecalho("XYZ-9\nsem data\nsem assinatura")
        self.assertEqual(codigos(res), [E_ID, E_DATA, E_ASSINATURA])
        self.assertEqual(res.guilda, "XYZ")  # prefixo legível, mesmo com ID inválido

    def test_cabecalho_vazio(self):
        self.assertEqual(codigos(validar_cabecalho("")), [E_ESTRUTURA])
        self.assertEqual(codigos(validar_cabecalho("   \n# só comentário\n")), [E_ESTRUTURA])

    def test_comentarios_ignorados(self):
        res = validar_cabecalho("# comentário\n" + cab())
        self.assertTrue(res.valido)

    def test_id_deve_ser_a_primeira_linha(self):
        # O decreto deve *iniciar* pelo identificador: ID na 2ª linha não vale.
        res = validar_cabecalho("Selado em 15/03/2043\nALQ-10492\n[Mestre Alabaster]")
        self.assertIn(E_ID, codigos(res))

    def test_data_embutida_em_texto(self):
        self.assertTrue(validar_cabecalho(cab(data="15/03/2043.")).valido)

    def test_apenas_a_primeira_assinatura_conta(self):
        res = validar_cabecalho("ALQ-10492\n15/03/2043\n[Ab]\n[Mestre Alabaster]")
        self.assertEqual(codigos(res), [E_ASSINATURA])

    def test_normalizacao_unicode(self):
        decomposto = unicodedata.normalize("NFD", "[Álvaro de Thornwood]")
        self.assertNotEqual(decomposto, "[Álvaro de Thornwood]")
        res = validar_cabecalho(f"ALQ-10492\n15/03/2043\n{decomposto}")
        self.assertTrue(res.valido)

    def test_mensagens_de_diagnostico(self):
        msg = validar_cabecalho(cab(assin="[Mestre 3 Alabaster]")).falhas[0].mensagem
        self.assertIn("números", msg)
        msg = validar_cabecalho(cab(assin="[Mago]")).falhas[0].mensagem
        self.assertIn("4 caracteres", msg)
        msg = validar_cabecalho(cab(data="15/03/1999")).falhas[0].mensagem
        self.assertIn("Terceira Era", msg)


if __name__ == "__main__":
    unittest.main()
