# Grimório Automático de Auditoria (GAA) — Reino de Aethelgard

Detector de pergaminhos falsificados: valida o cabeçote com **Expressões Regulares**, o corpo
com um **Autômato Finito Determinístico** explícito (tabela de transição) e guarda o inventário
em uma **Tabela Hash com encadeamento** implementada do zero. Gera o ranking de guildas com mais
tentativas de fraude em `.txt` ou `.json`.

Requisitos: Python 3.10+ (testado na 3.13), somente biblioteca padrão.

## Execução rápida

```bash
python main.py demo
python main.py auditar exemplos/decretos_validos.txt exemplos/decretos_invalidos.txt \
    --buscar ALQ-10492 --buscar FOR-3001 --relatorio relatorio.json
python main.py afd abbcabc --passos --tabela
python main.py interativo exemplos/decretos_validos.txt
python -m unittest discover -s tests -v      # 82 testes
```

Comandos do modo interativo: `carregar <arquivo>`, `buscar <ID>`, `ranking`, `relatorio <arquivo>`,
`afd <palavra>`, `estatisticas`, `ajuda`, `sair`.

## Estrutura

```
main.py                    ponto de entrada
gaa/regex_validador.py     Módulo 1 — expressões regulares (ID, data, assinatura)
gaa/afd.py                 Módulo 2 — AFD: tabela de transição, simulação, minimização, DOT
gaa/estruturas.py          Módulo 3 — tabela hash com encadeamento separado
gaa/auditor.py             orquestra os módulos, ranking e relatórios
gaa/pergaminho.py          leitura/divisão de arquivos de pergaminhos
gaa/modelos.py             tipos e códigos de falha
gaa/cli.py                 interface de linha de comando
exemplos/                  7 pergaminhos autênticos e 32 falsificados (com # ESPERADO:)
tests/                     suíte de testes (unittest)
docs/                      diagrama do AFD (afd.dot / afd.png / afd.svg) e relatório técnico
```

## Formato de um pergaminho

```
# comentário (ignorado no cabeçote)
ALQ-10492                              <- identificador: 3 maiúsculas, hífen, 4 a 6 dígitos
Selado na Terceira Era em 15/03/2043   <- data DD/MM/AAAA, ano 2000-2099
[Mestre Alabaster]                     <- assinatura: letras e espaços, 5 a 40 caracteres
---                                    <- separador cabeçote / corpo
abbcabc                                <- comandos rúnicos sobre {a,b,c}
===                                    <- separador entre pergaminhos
```

O corpo é aceito se tem número **par** de `a` e **termina em `bc`**. O AFD (4 estados, mínimo):

| Estado | a | b | c |
|---|---|---|---|
| → q0 | q3 | q1 | q0 |
| q1 | q3 | q1 | q2 |
| q2 (aceita) | q3 | q1 | q0 |
| q3 | q0 | q3 | q3 |

Códigos de fraude: `E_ESTRUTURA`, `E_ID`, `E_DATA`, `E_DATA_INEXISTENTE`, `E_ASSINATURA`,
`E_CORPO_ALFABETO`, `E_CORPO_AFD`. O AFD só roda se o cabeçote passar na validação por Regex.

O relatório técnico completo (modelagem formal, justificativa das regex, complexidade) está em `docs/`.

## Interface web

```bash
python server.py          # abre http://127.0.0.1:8000 (opcional: python server.py 9000)
```

O servidor usa só a biblioteca padrão e chama os módulos reais de `gaa/`. A página (`web/`) usa
Tailwind CSS e fontes via CDN, então precisa de internet para o visual completo.
